import { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, TextInput, ScrollView, Alert, Vibration, Animated } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function SpeechGuardMobile() {
  const insets = useSafeAreaInsets();
  
  // Enhanced state management
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('Ready to monitor your language! 😊');
  const [detectionHistory, setDetectionHistory] = useState([]);
  const [streak, setStreak] = useState(0);
  const [punishment, setPunishment] = useState({ 
    strikes: 0, 
    isActive: false, 
    type: 'none',
    timeLeft: 0
  });
  const [showSettings, setShowSettings] = useState(false);
  const [settings, setSettings] = useState({
    theme: 'light',
    categories: { sexual: true, abusive: true, hate: true, profanity: true, hindi: true },
    alerts: { sound: true, vibration: true },
    testMode: false,
    funMode: true,
    hardcore: false
  });
  const [customWords, setCustomWords] = useState([]);
  const [alert, setAlert] = useState({ show: false, text: '', word: '', category: '', time: '' });
  const [achievements, setAchievements] = useState([]);
  const [coins, setCoins] = useState(0);
  const [level, setLevel] = useState(1);
  const [xp, setXp] = useState(0);
  const [mood, setMood] = useState('happy');
  const [showConfetti, setShowConfetti] = useState(false);
  const [currentPunishment, setCurrentPunishment] = useState(null);

  const speechRecognition = useRef(null);
  const shakeAnimation = useRef(new Animated.Value(0)).current;
  const scaleAnimation = useRef(new Animated.Value(1)).current;

  // Enhanced profanity dictionary with severity levels
  const profanityDict = {
    sexual: {
      mild: ['sexy', 'hot', 'boobs'],
      moderate: ['sex', 'porn', 'nude', 'naked', 'ass', 'butt'],
      severe: ['dick', 'cock', 'pussy', 'vagina', 'penis', 'breast', 'slut', 'whore']
    },
    abusive: {
      mild: ['stupid', 'dumb', 'loser'],
      moderate: ['idiot', 'moron', 'freak', 'pathetic'],
      severe: ['retard', 'worthless', 'useless', 'trash', 'garbage']
    },
    hate: {
      mild: ['hate', 'annoying'],
      moderate: ['kill', 'die', 'violence'],
      severe: ['murder', 'terrorist', 'nazi', 'fascist', 'racist', 'destroy']
    },
    profanity: {
      mild: ['damn', 'hell', 'crap'],
      moderate: ['shit', 'piss', 'bastard', 'bitch'],
      severe: ['fuck', 'asshole', 'bullshit', 'fucking', 'motherfucker']
    },
    hindi: {
      mild: ['kamina', 'saala'],
      moderate: ['kutiya', 'harami', 'gandu'],
      severe: ['madarchod', 'bhenchod', 'bhosdike', 'randi', 'chutiya', 'gaand', 'lund']
    }
  };

  // Creative punishment types
  const punishmentTypes = [
    { id: 'timeout', name: 'Time Out Corner', message: '😭 Go sit in the corner and think about what you said!', duration: 30000 },
    { id: 'typing', name: 'Type Apology', message: '✍️ Type "I will not use bad words" 5 times!', duration: 0 },
    { id: 'meditation', name: 'Mindfulness Break', message: '🧘‍♀️ Take 3 deep breaths and think happy thoughts!', duration: 20000 },
    { id: 'dance', name: 'Silly Dance', message: '💃 Do a silly dance to shake off the negativity!', duration: 15000 },
    { id: 'compliment', name: 'Say Something Nice', message: '😊 Say 3 nice things about yourself out loud!', duration: 0 }
  ];

  // Achievements list
  const achievementsList = [
    { id: 'first_day', name: 'First Day Clean', description: 'Completed your first day without violations', icon: '🌟', coins: 10 },
    { id: 'week_warrior', name: 'Week Warrior', description: '7 days clean streak', icon: '🏆', coins: 50 },
    { id: 'month_master', name: 'Month Master', description: '30 days clean streak', icon: '👑', coins: 200 },
    { id: 'test_master', name: 'Test Master', description: 'Used test mode 10 times', icon: '🧪', coins: 15 }
  ];

  // Get mascot emoji based on mood
  const getMascotEmoji = () => {
    switch(mood) {
      case 'happy': return '😊';
      case 'warning': return '😐';
      case 'angry': return '😠';
      case 'locked': return '😤';
      case 'proud': return '🥳';
      default: return '😊';
    }
  };

  // Initialize speech recognition and load data
  useEffect(() => {
    // Initialize speech recognition for mobile
    if (typeof window !== 'undefined') {
      if ('webkitSpeechRecognition' in window) {
        speechRecognition.current = new window.webkitSpeechRecognition();
      } else if ('SpeechRecognition' in window) {
        speechRecognition.current = new window.SpeechRecognition();
      }

      if (speechRecognition.current) {
        speechRecognition.current.continuous = true;
        speechRecognition.current.interimResults = true;
        speechRecognition.current.lang = 'en-US';

        speechRecognition.current.onresult = (event) => {
          let currentTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            currentTranscript += event.results[i][0].transcript;
          }
          setTranscript(currentTranscript);
          analyzeProfanity(currentTranscript);
        };

        speechRecognition.current.onerror = (event) => {
          console.error('Speech recognition error:', event.error);
          setIsListening(false);
        };

        speechRecognition.current.onend = () => {
          if (isListening) {
            setTimeout(() => {
              if (isListening && speechRecognition.current) {
                speechRecognition.current.start();
              }
            }, 100);
          }
        };
      }
    }

    loadSettings();
    updateMood();
  }, []);

  // Load settings from AsyncStorage
  const loadSettings = async () => {
    try {
      const savedSettings = await AsyncStorage.getItem('speechGuardSettings');
      const savedHistory = await AsyncStorage.getItem('speechGuardHistory');
      const savedStreak = await AsyncStorage.getItem('speechGuardStreak');
      const savedAchievements = await AsyncStorage.getItem('speechGuardAchievements');
      const savedCoins = await AsyncStorage.getItem('speechGuardCoins');
      const savedLevel = await AsyncStorage.getItem('speechGuardLevel');
      const savedXP = await AsyncStorage.getItem('speechGuardXP');

      if (savedSettings) setSettings(JSON.parse(savedSettings));
      if (savedHistory) setDetectionHistory(JSON.parse(savedHistory));
      if (savedStreak) setStreak(parseInt(savedStreak));
      if (savedAchievements) setAchievements(JSON.parse(savedAchievements));
      if (savedCoins) setCoins(parseInt(savedCoins));
      if (savedLevel) setLevel(parseInt(savedLevel));
      if (savedXP) setXp(parseInt(savedXP));
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };

  // Save to AsyncStorage
  const saveToStorage = async (key, data) => {
    try {
      await AsyncStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
      console.error('Error saving to storage:', error);
    }
  };

  // Update mood based on current state
  const updateMood = () => {
    if (punishment.isActive) {
      setMood('locked');
    } else if (punishment.strikes >= 2) {
      setMood('angry');
    } else if (punishment.strikes >= 1) {
      setMood('warning');
    } else if (streak >= 7) {
      setMood('proud');
    } else {
      setMood('happy');
    }
  };

  // Add XP and handle level ups
  const addXP = (amount) => {
    const newXP = xp + amount;
    const newLevel = Math.floor(newXP / 100) + 1;
    
    if (newLevel > level) {
      triggerConfetti();
      setCoins(prev => prev + newLevel * 10);
      if (settings.alerts.vibration) {
        Vibration.vibrate([100, 50, 100, 50, 100]);
      }
    }
    
    setXp(newXP);
    setLevel(newLevel);
    saveToStorage('speechGuardXP', newXP);
    saveToStorage('speechGuardLevel', newLevel);
  };

  // Trigger confetti effect
  const triggerConfetti = () => {
    setShowConfetti(true);
    Animated.sequence([
      Animated.timing(scaleAnimation, {
        toValue: 1.2,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnimation, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start();
    setTimeout(() => setShowConfetti(false), 3000);
  };

  // Toggle listening
  const toggleListening = () => {
    if (!speechRecognition.current) {
      Alert.alert('Error', 'Speech recognition not supported on this device');
      return;
    }

    if (punishment.isActive) {
      Alert.alert('Locked!', 'Cannot listen while punishment is active! 😤');
      return;
    }

    if (isListening) {
      speechRecognition.current.stop();
      setIsListening(false);
    } else {
      speechRecognition.current.start();
      setIsListening(true);
      addXP(1);
    }
  };

  // Enhanced profanity analysis with severity
  const analyzeProfanity = (text) => {
    const normalizedText = text.toLowerCase();
    
    for (const [category, enabled] of Object.entries(settings.categories)) {
      if (!enabled) continue;
      
      const categoryWords = profanityDict[category] || {};
      
      for (const [severity, words] of Object.entries(categoryWords)) {
        const allWords = [...words, ...customWords];
        
        for (const word of allWords) {
          if (normalizedText.includes(word)) {
            handleDetection(word, category, severity);
            return;
          }
        }
      }
    }
  };

  // Handle profanity detection with creative punishments
  const handleDetection = (word, category, severity = 'moderate') => {
    const detection = {
      word,
      category,
      severity,
      time: new Date().toLocaleTimeString(),
      timestamp: Date.now()
    };
    
    // Add to history
    const newHistory = [detection, ...detectionHistory].slice(0, 50);
    setDetectionHistory(newHistory);
    saveToStorage('speechGuardHistory', newHistory);
    
    // Show alert
    showAlert(detection);
    
    // Apply creative punishment
    applyCreativePunishment(severity);
    
    // Reset streak and trigger effects
    resetStreak();
    triggerScreenShake();
    
    // Pause listening
    if (isListening && speechRecognition.current) {
      speechRecognition.current.stop();
      setTimeout(() => {
        if (!punishment.isActive && isListening) {
          speechRecognition.current.start();
        }
      }, 2000);
    }
    
    updateMood();
  };

  // Apply creative punishment system
  const applyCreativePunishment = (severity) => {
    const newStrikes = punishment.strikes + 1;
    let punishmentType;
    
    const strikeLimit = settings.hardcore ? 2 : 3;
    
    if (newStrikes >= strikeLimit) {
      punishmentType = punishmentTypes[Math.floor(Math.random() * punishmentTypes.length)];
      setCurrentPunishment(punishmentType);
      
      setPunishment({ 
        strikes: newStrikes, 
        isActive: true,
        type: punishmentType.id,
        timeLeft: punishmentType.duration
      });
      
      if (punishmentType.duration > 0) {
        setTimeout(() => {
          setPunishment(prev => ({ ...prev, isActive: false }));
          setCurrentPunishment(null);
          addXP(20);
        }, punishmentType.duration);
      }
    } else {
      setPunishment({ strikes: newStrikes, isActive: false, type: 'warning', timeLeft: 0 });
    }
    
    updateMood();
  };

  // Show enhanced alert
  const showAlert = (detection) => {
    setAlert({
      show: true,
      text: `🚨 NAUGHTY WORD: ${detection.word.toUpperCase()}!`,
      word: detection.word,
      category: detection.category,
      time: detection.time
    });

    // Enhanced vibration patterns for mobile
    if (settings.alerts.vibration) {
      if (detection.severity === 'severe') {
        Vibration.vibrate([300, 100, 300, 100, 300]);
      } else {
        Vibration.vibrate([200, 100, 200]);
      }
    }

    setTimeout(() => {
      setAlert(prev => ({ ...prev, show: false }));
    }, 4000);
  };

  // Reset streak with penalty
  const resetStreak = () => {
    if (streak > 0) {
      setCoins(prev => Math.max(0, prev - 5));
    }
    setStreak(0);
    saveToStorage('speechGuardStreak', 0);
  };

  // Screen shake effect for mobile
  const triggerScreenShake = () => {
    Animated.sequence([
      Animated.timing(shakeAnimation, {
        toValue: 10,
        duration: 50,
        useNativeDriver: true,
      }),
      Animated.timing(shakeAnimation, {
        toValue: -10,
        duration: 50,
        useNativeDriver: true,
      }),
      Animated.timing(shakeAnimation, {
        toValue: 10,
        duration: 50,
        useNativeDriver: true,
      }),
      Animated.timing(shakeAnimation, {
        toValue: 0,
        duration: 50,
        useNativeDriver: true,
      }),
    ]).start();
  };

  // Complete punishment task
  const completePunishmentTask = () => {
    if (currentPunishment && currentPunishment.duration === 0) {
      setPunishment(prev => ({ ...prev, isActive: false }));
      setCurrentPunishment(null);
      addXP(25);
      setCoins(prev => prev + 10);
    }
  };

  // Test detection
  const testDetection = (text) => {
    if (text.trim()) {
      analyzeProfanity(text);
    }
  };

  // Toggle theme
  const toggleTheme = () => {
    const newTheme = settings.theme === 'light' ? 'dark' : 'light';
    const newSettings = { ...settings, theme: newTheme };
    setSettings(newSettings);
    saveToStorage('speechGuardSettings', newSettings);
  };

  const isDark = settings.theme === 'dark';

  return (
    <Animated.View 
      style={{
        flex: 1,
        paddingTop: insets.top,
        paddingBottom: insets.bottom,
        backgroundColor: isDark ? '#1a1a2e' : '#f0f8ff',
        transform: [{ translateX: shakeAnimation }],
      }}
    >
      <StatusBar style={isDark ? 'light' : 'dark'} />
      
      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Confetti Effect */}
        {showConfetti && (
          <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 50 }}>
            <Text style={{ position: 'absolute', top: 50, left: '10%', fontSize: 40 }}>🎉</Text>
            <Text style={{ position: 'absolute', top: 100, left: '30%', fontSize: 40 }}>🎊</Text>
            <Text style={{ position: 'absolute', top: 80, left: '50%', fontSize: 40 }}>⭐</Text>
            <Text style={{ position: 'absolute', top: 120, left: '70%', fontSize: 40 }}>🌟</Text>
            <Text style={{ position: 'absolute', top: 60, left: '90%', fontSize: 40 }}>✨</Text>
          </View>
        )}

        {/* Enhanced Header with Stats */}
        <View style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 30,
          paddingBottom: 20,
          borderBottomWidth: 2,
          borderBottomColor: isDark ? '#6b46c1' : '#a855f7',
        }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
            <Animated.View style={{
              width: 80,
              height: 80,
              borderRadius: 40,
              backgroundColor: '#10b981',
              justifyContent: 'center',
              alignItems: 'center',
              marginRight: 15,
              transform: [{ scale: scaleAnimation }],
            }}>
              <Text style={{ fontSize: 40 }}>{getMascotEmoji()}</Text>
              <View style={{
                position: 'absolute',
                top: -5,
                right: -5,
                width: 30,
                height: 30,
                borderRadius: 15,
                backgroundColor: '#fbbf24',
                justifyContent: 'center',
                alignItems: 'center',
                borderWidth: 2,
                borderColor: 'white',
              }}>
                <Text style={{ fontSize: 14, fontWeight: 'bold', color: 'white' }}>{level}</Text>
              </View>
            </Animated.View>
            <View style={{ flex: 1 }}>
              <Text style={{
                fontSize: 28,
                fontWeight: 'bold',
                color: isDark ? 'white' : '#1f2937',
                marginBottom: 5,
              }}>
                Speech Guard 2.0
              </Text>
              <Text style={{
                fontSize: 16,
                color: isDark ? '#d1d5db' : '#6b7280',
                marginBottom: 8,
              }}>
                Level {level} • {coins} 🪙 • XP: {xp}/100
              </Text>
              <View style={{
                width: '80%',
                height: 8,
                backgroundColor: isDark ? '#374151' : '#e5e7eb',
                borderRadius: 4,
              }}>
                <View style={{
                  width: `${(xp % 100)}%`,
                  height: 8,
                  backgroundColor: '#10b981',
                  borderRadius: 4,
                }} />
              </View>
            </View>
          </View>
          <TouchableOpacity
            onPress={() => setShowSettings(true)}
            style={{
              width: 60,
              height: 60,
              borderRadius: 30,
              backgroundColor: '#a855f7',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <Text style={{ fontSize: 25 }}>⚙️</Text>
          </TouchableOpacity>
        </View>

        {/* Main Control Button */}
        <View style={{ alignItems: 'center', marginBottom: 30 }}>
          <TouchableOpacity
            onPress={toggleListening}
            disabled={punishment.isActive}
            style={{
              width: 180,
              height: 180,
              borderRadius: 90,
              backgroundColor: punishment.isActive ? '#9ca3af' : isListening ? '#ef4444' : '#10b981',
              justifyContent: 'center',
              alignItems: 'center',
              marginBottom: 20,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 4 },
              shadowOpacity: 0.3,
              shadowRadius: 8,
              elevation: 8,
            }}
          >
            <Text style={{ fontSize: 50, marginBottom: 5 }}>
              {punishment.isActive ? '🔒' : isListening ? '🛑' : '🎤'}
            </Text>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: 'white' }}>
              {punishment.isActive ? 'LOCKED' : isListening ? 'STOP' : 'START'}
            </Text>
          </TouchableOpacity>
          <Text style={{
            fontSize: 20,
            fontWeight: 'bold',
            textAlign: 'center',
            color: isDark ? 'white' : '#1f2937',
          }}>
            {punishment.isActive ? '🚫 Punishment Mode Active!' : 
             isListening ? '👂 Listening for naughty words...' : 
             '😊 Ready to be your guardian!'}
          </Text>
        </View>

        {/* Enhanced Streak Display */}
        <View style={{
          backgroundColor: isDark ? '#7c2d12' : '#fed7aa',
          borderRadius: 20,
          padding: 25,
          marginBottom: 25,
          alignItems: 'center',
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 4,
        }}>
          <Text style={{
            fontSize: 24,
            fontWeight: 'bold',
            color: isDark ? '#fed7aa' : '#7c2d12',
            marginBottom: 15,
            textAlign: 'center',
          }}>
            🔥 EPIC CLEAN STREAK 🔥
          </Text>
          <Text style={{
            fontSize: 80,
            fontWeight: 'bold',
            color: isDark ? '#fed7aa' : '#ea580c',
            marginBottom: 10,
          }}>
            {streak}
          </Text>
          <Text style={{
            fontSize: 24,
            fontWeight: 'bold',
            color: isDark ? '#fed7aa' : '#7c2d12',
            textAlign: 'center',
          }}>
            {streak === 1 ? 'day' : 'days'} of pure speech!
          </Text>
          {streak >= 7 && (
            <Text style={{
              fontSize: 18,
              fontWeight: 'bold',
              color: isDark ? '#fed7aa' : '#7c2d12',
              textAlign: 'center',
              marginTop: 10,
            }}>
              🏆 LEGENDARY STATUS! 🏆
            </Text>
          )}
        </View>

        {/* Creative Punishment Display */}
        {punishment.isActive && currentPunishment && (
          <View style={{
            backgroundColor: '#dc2626',
            borderRadius: 20,
            padding: 25,
            marginBottom: 25,
            alignItems: 'center',
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.2,
            shadowRadius: 4,
            elevation: 4,
          }}>
            <Text style={{
              fontSize: 24,
              fontWeight: 'bold',
              color: 'white',
              marginBottom: 15,
              textAlign: 'center',
            }}>
              🚨 PUNISHMENT TIME! 🚨
            </Text>
            <Text style={{ fontSize: 60, marginBottom: 15 }}>😤</Text>
            <Text style={{
              fontSize: 24,
              fontWeight: 'bold',
              color: 'white',
              marginBottom: 15,
              textAlign: 'center',
            }}>
              {currentPunishment.name}
            </Text>
            <Text style={{
              fontSize: 18,
              color: 'white',
              textAlign: 'center',
              marginBottom: 20,
              backgroundColor: 'rgba(255,255,255,0.2)',
              padding: 15,
              borderRadius: 10,
            }}>
              {currentPunishment.message}
            </Text>
            
            {currentPunishment.duration === 0 && (
              <TouchableOpacity
                onPress={completePunishmentTask}
                style={{
                  backgroundColor: 'white',
                  paddingHorizontal: 30,
                  paddingVertical: 15,
                  borderRadius: 25,
                }}
              >
                <Text style={{
                  fontSize: 18,
                  fontWeight: 'bold',
                  color: '#dc2626',
                }}>
                  ✅ I've Done It!
                </Text>
              </TouchableOpacity>
            )}
            
            {currentPunishment.duration > 0 && (
              <Text style={{
                fontSize: 18,
                fontWeight: 'bold',
                color: 'white',
                backgroundColor: 'rgba(255,255,255,0.2)',
                padding: 10,
                borderRadius: 10,
              }}>
                ⏰ Time remaining: {Math.ceil(punishment.timeLeft / 1000)} seconds
              </Text>
            )}
          </View>
        )}

        {/* Strike Warning System */}
        {punishment.strikes > 0 && !punishment.isActive && (
          <View style={{
            backgroundColor: punishment.strikes === 1 ? '#f59e0b' : punishment.strikes === 2 ? '#ef4444' : '#dc2626',
            borderRadius: 20,
            padding: 20,
            marginBottom: 25,
            alignItems: 'center',
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 4,
          }}>
            <Text style={{ fontSize: 50, marginBottom: 10 }}>
              {punishment.strikes === 1 ? '⚠️' : punishment.strikes === 2 ? '🔥' : '💀'}
            </Text>
            <Text style={{
              fontSize: 24,
              fontWeight: 'bold',
              color: 'white',
              marginBottom: 10,
            }}>
              Strike {punishment.strikes}/{settings.hardcore ? '2' : '3'}
            </Text>
            <Text style={{
              fontSize: 16,
              color: 'white',
              textAlign: 'center',
            }}>
              {punishment.strikes === 1 ? 'Watch your language! 😅' :
               punishment.strikes === 2 ? 'Last warning! Be careful! 😰' :
               'One more = punishment! 😱'}
            </Text>
          </View>
        )}

        {/* Enhanced Test Mode */}
        {settings.testMode && (
          <View style={{
            backgroundColor: isDark ? '#1e3a8a' : '#dbeafe',
            borderRadius: 20,
            padding: 20,
            marginBottom: 25,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 4,
          }}>
            <Text style={{
              fontSize: 24,
              fontWeight: 'bold',
              textAlign: 'center',
              marginBottom: 15,
              color: isDark ? '#dbeafe' : '#1e3a8a',
            }}>
              🧪 Testing Lab 🧪
            </Text>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <TextInput
                placeholder="Type naughty word to test..."
                placeholderTextColor={isDark ? '#9ca3af' : '#6b7280'}
                style={{
                  flex: 1,
                  paddingHorizontal: 15,
                  paddingVertical: 12,
                  borderRadius: 10,
                  backgroundColor: 'white',
                  fontSize: 16,
                  color: '#1f2937',
                }}
                onSubmitEditing={(e) => {
                  testDetection(e.nativeEvent.text);
                  e.target.clear();
                }}
              />
              <TouchableOpacity
                style={{
                  backgroundColor: '#8b5cf6',
                  paddingHorizontal: 20,
                  paddingVertical: 12,
                  borderRadius: 10,
                  justifyContent: 'center',
                }}
              >
                <Text style={{
                  color: 'white',
                  fontWeight: 'bold',
                  fontSize: 16,
                }}>
                  🚀 TEST!
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Enhanced Transcript */}
        <View style={{
          backgroundColor: isDark ? '#374151' : 'white',
          borderRadius: 20,
          padding: 20,
          marginBottom: 25,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 4,
        }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 }}>
            <Text style={{
              fontSize: 24,
              fontWeight: 'bold',
              color: isDark ? 'white' : '#1f2937',
            }}>
              📝 Live Transcript
            </Text>
            {isListening && (
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#ef4444', marginRight: 3 }} />
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#ef4444', marginRight: 3 }} />
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#ef4444', marginRight: 5 }} />
                <Text style={{ color: '#ef4444', fontWeight: 'bold', fontSize: 12 }}>LIVE</Text>
              </View>
            )}
          </View>
          <View style={{
            minHeight: 100,
            padding: 15,
            backgroundColor: isDark ? '#4b5563' : '#f3f4f6',
            borderRadius: 10,
          }}>
            <Text style={{
              fontSize: 16,
              color: isDark ? '#d1d5db' : '#374151',
              fontFamily: 'monospace',
            }}>
              {transcript}
            </Text>
          </View>
        </View>

        {/* Enhanced History */}
        <View style={{
          backgroundColor: isDark ? '#374151' : 'white',
          borderRadius: 20,
          padding: 20,
          marginBottom: 25,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 4,
        }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 }}>
            <Text style={{
              fontSize: 24,
              fontWeight: 'bold',
              color: isDark ? 'white' : '#1f2937',
            }}>
              📚 Hall of Shame
            </Text>
            <TouchableOpacity
              onPress={() => {
                setDetectionHistory([]);
                saveToStorage('speechGuardHistory', []);
              }}
              style={{
                backgroundColor: '#ef4444',
                paddingHorizontal: 15,
                paddingVertical: 8,
                borderRadius: 10,
              }}
            >
              <Text style={{
                color: 'white',
                fontWeight: 'bold',
                fontSize: 14,
              }}>
                🗑️ Clear
              </Text>
            </TouchableOpacity>
          </View>
          {detectionHistory.length === 0 ? (
            <Text style={{
              fontSize: 18,
              textAlign: 'center',
              color: isDark ? '#9ca3af' : '#6b7280',
              paddingVertical: 30,
            }}>
              🎉 No naughty words detected! 🎉
            </Text>
          ) : (
            <ScrollView style={{ maxHeight: 300 }}>
              {detectionHistory.slice(0, 10).map((item, index) => (
                <View key={index} style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: 15,
                  backgroundColor: isDark ? '#ef4444' : '#fee2e2',
                  borderRadius: 10,
                  marginBottom: 10,
                  borderLeftWidth: 4,
                  borderLeftColor: '#ef4444',
                }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
                    <Text style={{ fontSize: 24, marginRight: 10 }}>
                      {item.severity === 'severe' ? '🚨' : item.severity === 'moderate' ? '⚠️' : '😬'}
                    </Text>
                    <View>
                      <Text style={{
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: isDark ? 'white' : '#dc2626',
                      }}>
                        {item.word}
                      </Text>
                      <Text style={{
                        fontSize: 12,
                        color: isDark ? '#fecaca' : '#7f1d1d',
                        textTransform: 'capitalize',
                      }}>
                        {item.category} • {item.severity}
                      </Text>
                    </View>
                  </View>
                  <Text style={{
                    fontSize: 12,
                    color: isDark ? '#fecaca' : '#7f1d1d',
                    fontFamily: 'monospace',
                  }}>
                    {item.time}
                  </Text>
                </View>
              ))}
            </ScrollView>
          )}
        </View>

        {/* Achievements Section */}
        <View style={{
          backgroundColor: isDark ? '#7c2d12' : '#fef3c7',
          borderRadius: 20,
          padding: 20,
          marginBottom: 25,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 4,
        }}>
          <Text style={{
            fontSize: 24,
            fontWeight: 'bold',
            textAlign: 'center',
            marginBottom: 20,
            color: isDark ? '#fef3c7' : '#7c2d12',
          }}>
            🏆 Achievements
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
            {achievementsList.map((achievement) => (
              <View
                key={achievement.id}
                style={{
                  width: '48%',
                  backgroundColor: achievements.includes(achievement.id) ? '#10b981' : (isDark ? '#6b7280' : '#e5e7eb'),
                  borderRadius: 15,
                  padding: 15,
                  marginBottom: 10,
                  alignItems: 'center',
                }}
              >
                <Text style={{ fontSize: 30, marginBottom: 5 }}>{achievement.icon}</Text>
                <Text style={{
                  fontSize: 14,
                  fontWeight: 'bold',
                  textAlign: 'center',
                  color: achievements.includes(achievement.id) ? 'white' : (isDark ? '#d1d5db' : '#6b7280'),
                  marginBottom: 3,
                }}>
                  {achievement.name}
                </Text>
                <Text style={{
                  fontSize: 12,
                  textAlign: 'center',
                  color: achievements.includes(achievement.id) ? 'white' : (isDark ? '#d1d5db' : '#6b7280'),
                }}>
                  {achievement.coins} 🪙
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Privacy Notice */}
        <View style={{
          backgroundColor: isDark ? '#374151' : 'white',
          borderRadius: 15,
          padding: 20,
          alignItems: 'center',
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 4,
        }}>
          <Text style={{
            fontSize: 16,
            textAlign: 'center',
            color: isDark ? '#9ca3af' : '#6b7280',
            lineHeight: 24,
          }}>
            🔒 <Text style={{ fontWeight: 'bold' }}>PRIVACY GUARANTEED!</Text> Everything happens locally!{'\n'}
            <Text style={{ fontWeight: 'bold', fontSize: 18 }}>Speech Guard v2.0</Text> - Mobile Edition! 🎉
          </Text>
        </View>
      </ScrollView>

      {/* Enhanced Alert */}
      {alert.show && (
        <View style={{
          position: 'absolute',
          top: 100,
          left: 20,
          right: 20,
          backgroundColor: '#dc2626',
          borderRadius: 20,
          padding: 25,
          alignItems: 'center',
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 4 },
          shadowOpacity: 0.3,
          shadowRadius: 8,
          elevation: 10,
          zIndex: 100,
        }}>
          <Text style={{ fontSize: 50, marginBottom: 10 }}>🚨</Text>
          <Text style={{
            fontSize: 20,
            fontWeight: 'bold',
            color: 'white',
            marginBottom: 10,
            textAlign: 'center',
          }}>
            LANGUAGE ALERT!
          </Text>
          <Text style={{
            fontSize: 16,
            color: 'white',
            textAlign: 'center',
            backgroundColor: 'rgba(255,255,255,0.2)',
            padding: 10,
            borderRadius: 10,
            marginBottom: 5,
          }}>
            {alert.text}
          </Text>
          <Text style={{
            fontSize: 14,
            color: 'rgba(255,255,255,0.8)',
            fontFamily: 'monospace',
          }}>
            {alert.time}
          </Text>
        </View>
      )}

      {/* Settings Modal */}
      {showSettings && (
        <View style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.7)',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 200,
        }}>
          <View style={{
            backgroundColor: isDark ? '#374151' : 'white',
            borderRadius: 20,
            padding: 25,
            width: '90%',
            maxHeight: '80%',
          }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <Text style={{
                fontSize: 28,
                fontWeight: 'bold',
                color: isDark ? 'white' : '#1f2937',
              }}>
                ⚙️ Settings
              </Text>
              <TouchableOpacity
                onPress={() => setShowSettings(false)}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: isDark ? '#6b7280' : '#e5e7eb',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}
              >
                <Text style={{ fontSize: 20 }}>✖️</Text>
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              {/* Theme Toggle */}
              <View style={{
                backgroundColor: isDark ? '#4b5563' : '#f3f4f6',
                borderRadius: 15,
                padding: 20,
                marginBottom: 15,
              }}>
                <Text style={{
                  fontSize: 20,
                  fontWeight: 'bold',
                  marginBottom: 15,
                  color: isDark ? 'white' : '#1f2937',
                }}>
                  🎨 Theme
                </Text>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                  <Text style={{ fontSize: 16, color: isDark ? '#d1d5db' : '#6b7280' }}>☀️ Light</Text>
                  <TouchableOpacity
                    onPress={toggleTheme}
                    style={{
                      width: 60,
                      height: 30,
                      borderRadius: 15,
                      backgroundColor: settings.theme === 'dark' ? '#8b5cf6' : '#d1d5db',
                      justifyContent: 'center',
                      paddingHorizontal: 3,
                    }}
                  >
                    <View style={{
                      width: 24,
                      height: 24,
                      borderRadius: 12,
                      backgroundColor: 'white',
                      alignSelf: settings.theme === 'dark' ? 'flex-end' : 'flex-start',
                    }} />
                  </TouchableOpacity>
                  <Text style={{ fontSize: 16, color: isDark ? '#d1d5db' : '#6b7280' }}>🌙 Dark</Text>
                </View>
              </View>

              {/* Detection Categories */}
              <View style={{
                backgroundColor: isDark ? '#4b5563' : '#f3f4f6',
                borderRadius: 15,
                padding: 20,
                marginBottom: 15,
              }}>
                <Text style={{
                  fontSize: 20,
                  fontWeight: 'bold',
                  marginBottom: 15,
                  color: isDark ? 'white' : '#1f2937',
                }}>
                  🎯 Detection Categories
                </Text>
                {Object.entries(settings.categories).map(([category, enabled]) => (
                  <View key={category} style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    paddingVertical: 10,
                    borderBottomWidth: 1,
                    borderBottomColor: isDark ? '#6b7280' : '#e5e7eb',
                  }}>
                    <Text style={{
                      fontSize: 16,
                      textTransform: 'capitalize',
                      color: isDark ? '#d1d5db' : '#374151',
                    }}>
                      {category === 'sexual' ? '🔞' : category === 'abusive' ? '😡' : category === 'hate' ? '💢' : category === 'profanity' ? '🤬' : '🇮🇳'} {category}
                    </Text>
                    <TouchableOpacity
                      onPress={() => {
                        const newSettings = {
                          ...settings,
                          categories: { ...settings.categories, [category]: !enabled }
                        };
                        setSettings(newSettings);
                        saveToStorage('speechGuardSettings', newSettings);
                      }}
                      style={{
                        width: 50,
                        height: 25,
                        borderRadius: 12.5,
                        backgroundColor: enabled ? '#10b981' : '#d1d5db',
                        justifyContent: 'center',
                        paddingHorizontal: 2,
                      }}
                    >
                      <View style={{
                        width: 21,
                        height: 21,
                        borderRadius: 10.5,
                        backgroundColor: 'white',
                        alignSelf: enabled ? 'flex-end' : 'flex-start',
                      }} />
                    </TouchableOpacity>
                  </View>
                ))}
              </View>

              {/* Mode Toggles */}
              <View style={{
                backgroundColor: isDark ? '#4b5563' : '#f3f4f6',
                borderRadius: 15,
                padding: 20,
                marginBottom: 15,
              }}>
                <Text style={{
                  fontSize: 20,
                  fontWeight: 'bold',
                  marginBottom: 15,
                  color: isDark ? 'white' : '#1f2937',
                }}>
                  🎮 Mode Settings
                </Text>
                
                {/* Fun Mode */}
                <View style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  paddingVertical: 10,
                  borderBottomWidth: 1,
                  borderBottomColor: isDark ? '#6b7280' : '#e5e7eb',
                }}>
                  <View>
                    <Text style={{
                      fontSize: 16,
                      fontWeight: 'bold',
                      color: isDark ? '#d1d5db' : '#374151',
                    }}>
                      🎮 Fun Mode
                    </Text>
                    <Text style={{
                      fontSize: 12,
                      color: isDark ? '#9ca3af' : '#6b7280',
                    }}>
                      Extra animations & effects
                    </Text>
                  </View>
                  <TouchableOpacity
                    onPress={() => {
                      const newSettings = { ...settings, funMode: !settings.funMode };
                      setSettings(newSettings);
                      saveToStorage('speechGuardSettings', newSettings);
                    }}
                    style={{
                      width: 50,
                      height: 25,
                      borderRadius: 12.5,
                      backgroundColor: settings.funMode ? '#10b981' : '#d1d5db',
                      justifyContent: 'center',
                      paddingHorizontal: 2,
                    }}
                  >
                    <View style={{
                      width: 21,
                      height: 21,
                      borderRadius: 10.5,
                      backgroundColor: 'white',
                      alignSelf: settings.funMode ? 'flex-end' : 'flex-start',
                    }} />
                  </TouchableOpacity>
                </View>

                {/* Hardcore Mode */}
                <View style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  paddingVertical: 10,
                  borderBottomWidth: 1,
                  borderBottomColor: isDark ? '#6b7280' : '#e5e7eb',
                }}>
                  <View>
                    <Text style={{
                      fontSize: 16,
                      fontWeight: 'bold',
                      color: isDark ? '#d1d5db' : '#374151',
                    }}>
                      💀 Hardcore Mode
                    </Text>
                    <Text style={{
                      fontSize: 12,
                      color: isDark ? '#9ca3af' : '#6b7280',
                    }}>
                      2 strikes instead of 3
                    </Text>
                  </View>
                  <TouchableOpacity
                    onPress={() => {
                      const newSettings = { ...settings, hardcore: !settings.hardcore };
                      setSettings(newSettings);
                      saveToStorage('speechGuardSettings', newSettings);
                    }}
                    style={{
                      width: 50,
                      height: 25,
                      borderRadius: 12.5,
                      backgroundColor: settings.hardcore ? '#ef4444' : '#d1d5db',
                      justifyContent: 'center',
                      paddingHorizontal: 2,
                    }}
                  >
                    <View style={{
                      width: 21,
                      height: 21,
                      borderRadius: 10.5,
                      backgroundColor: 'white',
                      alignSelf: settings.hardcore ? 'flex-end' : 'flex-start',
                    }} />
                  </TouchableOpacity>
                </View>

                {/* Test Mode */}
                <View style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  paddingVertical: 10,
                }}>
                  <Text style={{
                    fontSize: 16,
                    fontWeight: 'bold',
                    color: isDark ? '#d1d5db' : '#374151',
                  }}>
                    🧪 Test Mode
                  </Text>
                  <TouchableOpacity
                    onPress={() => {
                      const newSettings = { ...settings, testMode: !settings.testMode };
                      setSettings(newSettings);
                      saveToStorage('speechGuardSettings', newSettings);
                    }}
                    style={{
                      width: 50,
                      height: 25,
                      borderRadius: 12.5,
                      backgroundColor: settings.testMode ? '#f59e0b' : '#d1d5db',
                      justifyContent: 'center',
                      paddingHorizontal: 2,
                    }}
                  >
                    <View style={{
                      width: 21,
                      height: 21,
                      borderRadius: 10.5,
                      backgroundColor: 'white',
                      alignSelf: settings.testMode ? 'flex-end' : 'flex-start',
                    }} />
                  </TouchableOpacity>
                </View>
              </View>

              {/* Data Management */}
              <TouchableOpacity
                onPress={() => {
                  Alert.alert(
                    '🗑️ Clear All Data',
                    'This will delete all your progress, achievements, and settings. This cannot be undone!',
                    [
                      { text: 'Cancel', style: 'cancel' },
                      { 
                        text: 'Delete Everything', 
                        style: 'destructive',
                        onPress: async () => {
                          try {
                            await AsyncStorage.clear();
                            Alert.alert('Success', 'All data cleared!');
                            // Reset all state
                            setSettings({
                              theme: 'light',
                              categories: { sexual: true, abusive: true, hate: true, profanity: true, hindi: true },
                              alerts: { sound: true, vibration: true },
                              testMode: false,
                              funMode: true,
                              hardcore: false
                            });
                            setDetectionHistory([]);
                            setStreak(0);
                            setAchievements([]);
                            setCoins(0);
                            setLevel(1);
                            setXp(0);
                            setPunishment({ strikes: 0, isActive: false, type: 'none', timeLeft: 0 });
                            setShowSettings(false);
                          } catch (error) {
                            Alert.alert('Error', 'Failed to clear data');
                          }
                        }
                      }
                    ]
                  );
                }}
                style={{
                  backgroundColor: '#ef4444',
                  borderRadius: 15,
                  padding: 20,
                  alignItems: 'center',
                }}
              >
                <Text style={{
                  fontSize: 18,
                  fontWeight: 'bold',
                  color: 'white',
                }}>
                  🗑️ Nuclear Reset (Clear All)
                </Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      )}
    </Animated.View>
  );
}