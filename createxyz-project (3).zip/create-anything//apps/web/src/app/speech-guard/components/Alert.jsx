export function Alert({ alert }) {
  if (!alert.show) return null;

  return (
    <div
      className={`fixed top-6 right-6 p-8 rounded-2xl shadow-2xl z-50 max-w-sm transform transition-all duration-500 animate-bounce ${
        alert.category === "achievement"
          ? "bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 text-white"
          : "bg-gradient-to-r from-red-400 via-pink-500 to-red-600 text-white"
      }`}
    >
      <div className="text-center">
        <div className="text-4xl mb-3">
          {alert.category === "achievement" ? "🎉" : "🚨"}
        </div>
        <div className="font-bold text-xl mb-2">
          {alert.category === "achievement"
            ? "Achievement!"
            : "Language Alert!"}
        </div>
        <div className="mb-2 text-lg">{alert.text}</div>
        <div className="text-sm opacity-90">{alert.time}</div>
      </div>
    </div>
  );
}
