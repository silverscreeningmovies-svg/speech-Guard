const getMascotEmoji = (mood) => {
  switch (mood) {
    case "happy": return "😊";
    case "warning": return "😐";
    case "angry": return "😠";
    case "locked": return "😤";
    case "proud": return "🥳";
    default: return "😊";
  }
};

export function Header({ level, coins, xp, mood, setShowSettings }) {
  return (
    <div className="flex justify-between items-center mb-8 pb-6 border-b-2 border-gradient-to-r from-pink-300 to-purple-300">
      <div className="flex items-center gap-4">
        <div className="relative">
          <div className="w-16 h-16 bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 rounded-full flex items-center justify-center text-3xl animate-bounce">
            {getMascotEmoji(mood)}
          </div>
          <div className="absolute -top-2 -right-2 w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center text-xs font-bold">
            {level}
          </div>
        </div>
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 bg-clip-text text-transparent animate-pulse">
            Speech Guard
          </h1>
          <div className="text-sm text-gray-600 dark:text-gray-400">
            Level {level} • {coins} 🪙 • XP: {xp}/100
          </div>
          <div className="w-32 h-2 bg-gray-200 rounded-full mt-1">
            <div
              className="h-2 bg-gradient-to-r from-green-400 to-blue-500 rounded-full transition-all duration-500"
              style={{ width: `${xp % 100}%` }}
            />
          </div>
        </div>
      </div>
      <button
        onClick={() => setShowSettings(true)}
        className="w-14 h-14 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full shadow-lg flex items-center justify-center hover:shadow-xl transition-all duration-200 animate-spin-slow hover:animate-pulse text-2xl"
        aria-label="Open Settings"
      >
        ⚙️
      </button>
    </div>
  );
}
