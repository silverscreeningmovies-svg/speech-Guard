export function Transcript({ transcript, isListening }) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-xl mb-8 relative overflow-hidden">
      <div className="absolute top-0 right-0 text-6xl opacity-10">🎙️</div>
      <h3 className="text-2xl font-bold mb-6 text-center">
        📝 Live Transcript
      </h3>
      <div className="min-h-[120px] p-6 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-600 rounded-2xl text-gray-700 dark:text-gray-300 text-lg relative">
        {isListening && (
          <div className="absolute top-2 right-2 flex space-x-1">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse delay-75"></div>
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse delay-150"></div>
          </div>
        )}
        {transcript}
      </div>
    </div>
  );
}
