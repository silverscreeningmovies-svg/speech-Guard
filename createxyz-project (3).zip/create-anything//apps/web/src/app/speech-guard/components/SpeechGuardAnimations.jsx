export function SpeechGuardAnimations() {
  return (
    <style jsx>{`
      @keyframes slide-in-right {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
      @keyframes shake {
        0%, 100% { transform: translateX(0); }
        10%, 30%, 50%, 70%, 90% { transform: translateX(-10px); }
        20%, 40%, 60%, 80% { transform: translateX(10px); }
      }
      @keyframes spin-slow {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
      .animate-slide-in-right { animation: slide-in-right 0.3s ease-out; }
      .animate-shake { animation: shake 0.5s ease-in-out; }
      .animate-spin-slow { animation: spin-slow 3s linear infinite; }
      .confetti {
        position: absolute;
        font-size: 2rem;
        animation: confetti-fall 3s linear infinite;
      }
      .confetti:nth-child(1) { left: 10%; animation-delay: 0s; }
      .confetti:nth-child(2) { left: 30%; animation-delay: 0.5s; }
      .confetti:nth-child(3) { left: 50%; animation-delay: 1s; }
      .confetti:nth-child(4) { left: 70%; animation-delay: 1.5s; }
      .confetti:nth-child(5) { left: 90%; animation-delay: 2s; }
      @keyframes confetti-fall {
        0% { transform: translateY(-100vh) rotate(0deg); opacity: 1; }
        100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
      }
    `}</style>
  );
}
