export function PunishmentDisplay({ punishment, currentPunishment, completePunishmentTask }) {
  if (!punishment.isActive || !currentPunishment) return null;

  return (
    <div className="bg-gradient-to-r from-red-400 via-pink-500 to-purple-600 text-white rounded-3xl p-8 shadow-2xl mb-8 text-center animate-pulse">
      <div className="text-3xl mb-4">🚨 PUNISHMENT TIME! 🚨</div>
      <div className="text-6xl mb-4">😤</div>
      <div className="text-2xl font-bold mb-4">
        {currentPunishment.name}
      </div>
      <div className="text-xl mb-6">{currentPunishment.message}</div>

      {currentPunishment.duration === 0 && (
        <button
          onClick={completePunishmentTask}
          className="bg-white text-purple-600 px-8 py-4 rounded-full font-bold text-xl hover:bg-gray-100 transition-all transform hover:scale-105"
        >
          ✅ I've Done It!
        </button>
      )}

      {currentPunishment.duration > 0 && (
        <div className="text-lg">
          ⏰ Time remaining:{" "}
          {Math.ceil(punishment.duration / 1000)} seconds
        </div>
      )}
    </div>
  );
}
