export function StreakDisplay({ streak }) {
  return (
    <div className="bg-gradient-to-r from-yellow-100 via-yellow-200 to-yellow-300 dark:from-yellow-800 dark:via-yellow-700 dark:to-yellow-600 rounded-3xl p-8 shadow-xl mb-8 text-center relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full opacity-10">
        <div className="text-9xl absolute top-4 left-4">🔥</div>
        <div className="text-6xl absolute top-8 right-8">⭐</div>
        <div className="text-7xl absolute bottom-4 left-1/2 transform -translate-x-1/2">
          ✨
        </div>
      </div>
      <div className="relative z-10">
        <div className="text-2xl font-bold text-yellow-800 dark:text-yellow-200 mb-3">
          🔥 CLEAN STREAK FIRE 🔥
        </div>
        <div className="text-8xl font-black text-yellow-600 dark:text-yellow-300 mb-2 animate-bounce">
          {streak}
        </div>
        <div className="text-2xl font-bold text-yellow-800 dark:text-yellow-200">
          {streak === 1 ? "day" : "days"} of pure speech!
        </div>
        {streak >= 7 && (
          <div className="mt-4 text-lg font-semibold text-yellow-700 dark:text-yellow-200 animate-pulse">
            🏆 You're on fire! Keep it up, champion! 🏆
          </div>
        )}
      </div>
    </div>
  );
}
