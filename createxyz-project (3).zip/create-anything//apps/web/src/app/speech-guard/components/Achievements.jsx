import { achievementsList } from "@/app/speech-guard/lib/constants";

export function Achievements({ achievements }) {
  return (
    <div className="bg-gradient-to-r from-yellow-100 to-orange-100 dark:from-yellow-900 dark:to-orange-900 rounded-3xl p-8 shadow-xl mb-8">
      <h3 className="text-2xl font-bold mb-6 text-center">
        🏆 Achievements Unlocked
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {achievementsList.map((achievement) => (
          <div
            key={achievement.id}
            className={`p-4 rounded-2xl text-center transition-all transform hover:scale-105 ${
              achievements.includes(achievement.id)
                ? "bg-gradient-to-r from-green-400 to-blue-500 text-white shadow-lg"
                : "bg-gray-200 dark:bg-gray-700 text-gray-500"
            }`}
          >
            <div className="text-3xl mb-2">{achievement.icon}</div>
            <div className="font-bold text-sm">{achievement.name}</div>
            <div className="text-xs mt-1">{achievement.coins} 🪙</div>
          </div>
        ))}
      </div>
    </div>
  );
}
