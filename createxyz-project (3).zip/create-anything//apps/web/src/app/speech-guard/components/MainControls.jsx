export function MainControls({ isListening, punishment, toggleListening }) {
  const buttonClasses = `w-40 h-40 rounded-full text-2xl font-bold transition-all duration-500 mb-6 relative overflow-hidden ${
    isListening
      ? "bg-gradient-to-r from-red-400 via-red-500 to-red-600 text-white shadow-2xl shadow-red-500/50 animate-pulse scale-110"
      : punishment.isActive
        ? "bg-gray-400 text-gray-600 cursor-not-allowed"
        : "bg-gradient-to-r from-green-400 via-green-500 to-green-600 text-white shadow-2xl shadow-green-500/50 hover:scale-105 hover:shadow-3xl"
  }`;

  const statusText = punishment.isActive
    ? "Punishment Mode Active!"
    : isListening
      ? "👂 Listening for naughty words..."
      : "😊 Ready to be your language guardian!";

  const buttonText = punishment.isActive
    ? "🔒 LOCKED"
    : isListening
      ? "🛑 STOP"
      : "🎤 START";

  return (
    <div className="text-center mb-8">
      <button
        onClick={toggleListening}
        className={buttonClasses}
        disabled={punishment.isActive}
      >
        <div className="absolute inset-0 bg-white opacity-20 rounded-full animate-ping" />
        <span className="relative z-10">{buttonText}</span>
      </button>
      <div className="text-xl font-semibold">{statusText}</div>
    </div>
  );
}
