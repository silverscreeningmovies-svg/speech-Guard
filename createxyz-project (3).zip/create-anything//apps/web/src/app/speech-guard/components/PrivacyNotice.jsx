export function PrivacyNotice() {
  return (
    <div className="text-center text-gray-500 dark:text-gray-400 text-sm bg-white dark:bg-gray-800 rounded-2xl p-4">
      🔒 Your secrets are safe! Everything happens locally - no snitching to
      servers! 🤐
      <br />
      <span className="font-bold">Speech Guard v2.0</span> - Now with 100%
      more fun! 🎉
    </div>
  );
}
