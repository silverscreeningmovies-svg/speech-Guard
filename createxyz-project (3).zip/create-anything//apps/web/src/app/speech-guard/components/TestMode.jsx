export function TestMode({ testDetection }) {
  const handleTest = (inputElement) => {
    if (inputElement && inputElement.value) {
      testDetection(inputElement.value);
      inputElement.value = "";
    }
  };

  return (
    <div className="bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900 dark:to-purple-900 rounded-3xl p-6 shadow-xl mb-8">
      <h3 className="text-2xl font-bold mb-4 text-center">
        🧪 Testing Laboratory 🧪
      </h3>
      <div className="flex gap-3">
        <input
          type="text"
          id="test-input"
          placeholder="Type something naughty to test... 😈"
          className="flex-1 px-6 py-4 rounded-2xl border-2 border-purple-300 bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-lg focus:border-purple-500 focus:ring-2 focus:ring-purple-200"
          onKeyPress={(e) => {
            if (e.key === "Enter") {
              handleTest(e.target);
            }
          }}
        />
        <button
          onClick={() => {
            const input = document.getElementById("test-input");
            handleTest(input);
          }}
          className="px-8 py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl hover:from-purple-600 hover:to-pink-600 transition-all transform hover:scale-105 font-bold text-lg"
        >
          🚀 TEST!
        </button>
      </div>
    </div>
  );
}
