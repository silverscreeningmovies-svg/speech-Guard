const Toggle = ({ checked, onChange, bgClass, children }) => (
    <div className={children ? "flex justify-between items-center" : ""}>
      {children}
      <button
        onClick={onChange}
        className={`w-16 h-8 rounded-full transition-all duration-300 relative ${
          checked ? bgClass : "bg-gray-300"
        }`}
      >
        <div
          className={`w-6 h-6 bg-white rounded-full absolute top-1 transition-transform duration-300 ${
            checked ? "translate-x-9" : "translate-x-1"
          }`}
        />
      </button>
    </div>
  );
  
  export function SettingsModal({ show, onClose, settings, onSettingsChange, onExport, onClearAll }) {
    if (!show) return null;
  
    const handleSettingToggle = (key) => {
      onSettingsChange({ ...settings, [key]: !settings[key] });
    };
  
    const handleCategoryToggle = (category) => {
      onSettingsChange({
        ...settings,
        categories: { ...settings.categories, [category]: !settings.categories[category] },
      });
    };
  
    return (
      <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
              ⚙️ Settings & Controls
            </h2>
            <button
              onClick={onClose}
              className="w-10 h-10 flex items-center justify-center text-gray-500 hover:text-gray-700 text-3xl hover:bg-gray-100 rounded-full"
            >
              ✖️
            </button>
          </div>
  
          <div className="mb-8 p-6 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900 dark:to-purple-900 rounded-2xl">
            <label className="block text-xl font-bold mb-4">🎨 Theme</label>
            <div className="flex items-center gap-4">
              <span className="text-lg">☀️ Light</span>
              <Toggle
                checked={settings.theme === "dark"}
                onChange={() => onSettingsChange({ ...settings, theme: settings.theme === "light" ? "dark" : "light" })}
                bgClass="bg-purple-500"
              />
              <span className="text-lg">🌙 Dark</span>
            </div>
          </div>
  
          <div className="mb-8 p-6 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900 dark:to-blue-900 rounded-2xl">
            <Toggle checked={settings.funMode} onChange={() => handleSettingToggle("funMode")} bgClass="bg-green-500">
              <div>
                <span className="text-xl font-bold">🎮 Fun Mode</span>
                <div className="text-sm text-gray-600 dark:text-gray-400">Extra animations and effects</div>
              </div>
            </Toggle>
          </div>
  
          <div className="mb-8 p-6 bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-900 dark:to-orange-900 rounded-2xl">
            <Toggle checked={settings.hardcore} onChange={() => handleSettingToggle("hardcore")} bgClass="bg-red-500">
              <div>
                <span className="text-xl font-bold">💀 Hardcore Mode</span>
                <div className="text-sm text-gray-600 dark:text-gray-400">Stricter punishments and faster strikes</div>
              </div>
            </Toggle>
          </div>
  
          <div className="mb-8 p-6 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900 dark:to-pink-900 rounded-2xl">
            <label className="block text-xl font-bold mb-4">🎯 Detection Categories</label>
            <div className="space-y-4">
              {Object.entries(settings.categories).map(([category, enabled]) => (
                <div key={category} className="flex justify-between items-center p-3 bg-white dark:bg-gray-700 rounded-xl">
                  <span className="capitalize text-lg font-semibold">{category} Content</span>
                  <Toggle checked={enabled} onChange={() => handleCategoryToggle(category)} bgClass="bg-green-500" />
                </div>
              ))}
            </div>
          </div>
  
          <div className="mb-8 p-6 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900 dark:to-orange-900 rounded-2xl">
            <Toggle checked={settings.testMode} onChange={() => handleSettingToggle("testMode")} bgClass="bg-yellow-500">
              <span className="text-xl font-bold">🧪 Test Mode</span>
            </Toggle>
          </div>
  
          <div className="space-y-4">
            <button onClick={onExport} className="w-full py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-2xl hover:from-blue-600 hover:to-purple-700 transition-all font-bold text-lg transform hover:scale-105">
              📥 Export My Data
            </button>
            <button onClick={onClearAll} className="w-full py-4 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-2xl hover:from-red-600 hover:to-red-700 transition-all font-bold text-lg transform hover:scale-105">
              🗑️ Clear All Data
            </button>
          </div>
        </div>
      </div>
    );
  }
