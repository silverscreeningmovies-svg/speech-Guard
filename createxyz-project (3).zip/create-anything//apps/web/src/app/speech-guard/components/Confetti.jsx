export function Confetti({ showConfetti }) {
  if (!showConfetti) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      <div className="confetti">🎉</div>
      <div className="confetti">🎊</div>
      <div className="confetti">⭐</div>
      <div className="confetti">🌟</div>
      <div className="confetti">✨</div>
    </div>
  );
}
