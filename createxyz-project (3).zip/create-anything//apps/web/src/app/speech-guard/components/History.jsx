export function History({ detectionHistory, clearHistory }) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-xl mb-8">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-2xl font-bold">
          📚 Naughty Words Hall of Shame
        </h3>
        <button
          onClick={clearHistory}
          className="px-6 py-3 bg-gradient-to-r from-red-400 to-red-600 text-white rounded-2xl hover:from-red-500 hover:to-red-700 transition-all transform hover:scale-105 font-bold"
        >
          🗑️ Clear Shame
        </button>
      </div>
      <div className="space-y-4 max-h-80 overflow-y-auto">
        {detectionHistory.length === 0 ? (
          <div className="text-center text-gray-500 py-8 text-xl">
            🎉 No naughty words detected yet! You're doing great! 🎉
          </div>
        ) : (
          detectionHistory.slice(0, 10).map((item, index) => (
            <div
              key={index}
              className="flex justify-between items-center p-4 bg-gradient-to-r from-red-50 to-pink-50 dark:from-red-900 dark:to-pink-900 rounded-2xl border-l-4 border-red-500 transform hover:scale-102 transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="text-2xl">
                  {item.severity === "severe" ? "🚨" : item.severity === "moderate" ? "⚠️" : "😬"}
                </div>
                <div>
                  <div className="font-bold text-red-600 dark:text-red-400 text-lg">
                    {item.word}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400 capitalize">
                    {item.category} • {item.severity}
                  </div>
                </div>
              </div>
              <div className="text-sm text-gray-500 font-mono">
                {item.time}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
