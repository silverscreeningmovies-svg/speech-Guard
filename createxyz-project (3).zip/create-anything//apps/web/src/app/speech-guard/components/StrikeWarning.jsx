export function StrikeWarning({ punishment }) {
  if (punishment.strikes === 0 || punishment.isActive) return null;

  const strikeClasses = `rounded-3xl p-6 shadow-xl mb-8 text-center ${
    punishment.strikes === 1
      ? "bg-gradient-to-r from-yellow-300 to-orange-400"
      : punishment.strikes === 2
        ? "bg-gradient-to-r from-orange-400 to-red-500 animate-pulse"
        : "bg-gradient-to-r from-red-500 to-red-700"
  }`;

  const strikeEmoji = punishment.strikes === 1 ? "⚠️" : punishment.strikes === 2 ? "🔥" : "💀";
  const strikeText =
    punishment.strikes === 1
      ? "Watch your language! 😅"
      : punishment.strikes === 2
        ? "Last warning! Be careful! 😰"
        : "One more and you get a punishment! 😱";

  return (
    <div className={strikeClasses}>
      <div className="text-3xl mb-2">{strikeEmoji}</div>
      <div className="text-2xl font-bold text-white mb-2">
        Strike {punishment.strikes}/3
      </div>
      <div className="text-lg text-white">{strikeText}</div>
    </div>
  );
}
