'use client';
import { useState, useEffect, useRef } from 'react';

export default function SpeechGuardPage() {
  // Enhanced state management
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('Ready to monitor your language! 😊');
  const [detectionHistory, setDetectionHistory] = useState([]);
  const [streak, setStreak] = useState(0);
  const [punishment, setPunishment] = useState({ 
    strikes: 0, 
    isActive: false, 
    type: 'none',
    timeLeft: 0
  });
  const [showSettings, setShowSettings] = useState(false);
  const [settings, setSettings] = useState({
    theme: 'light',
    sensitivity: 'medium',
    categories: { sexual: true, abusive: true, hate: true, profanity: true, hindi: true },
    alerts: { sound: true, vibration: true },
    testMode: false,
    funMode: true,
    hardcore: false
  });
  const [customWords, setCustomWords] = useState([]);
  const [alert, setAlert] = useState({ show: false, text: '', word: '', category: '', time: '' });
  const [achievements, setAchievements] = useState([]);
  const [coins, setCoins] = useState(0);
  const [level, setLevel] = useState(1);
  const [xp, setXp] = useState(0);
  const [mood, setMood] = useState('happy');
  const [shakeScreen, setShakeScreen] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [currentPunishment, setCurrentPunishment] = useState(null);

  const speechRecognition = useRef(null);
  const alertSound = useRef(null);

  // Enhanced profanity dictionary with severity levels
  const profanityDict = {
    sexual: {
      mild: ['sexy', 'hot', 'boobs'],
      moderate: ['sex', 'porn', 'nude', 'naked', 'ass', 'butt'],
      severe: ['dick', 'cock', 'pussy', 'vagina', 'penis', 'breast', 'slut', 'whore']
    },
    abusive: {
      mild: ['stupid', 'dumb', 'loser'],
      moderate: ['idiot', 'moron', 'freak', 'pathetic'],
      severe: ['retard', 'worthless', 'useless', 'trash', 'garbage']
    },
    hate: {
      mild: ['hate', 'annoying'],
      moderate: ['kill', 'die', 'violence'],
      severe: ['murder', 'terrorist', 'nazi', 'fascist', 'racist', 'destroy']
    },
    profanity: {
      mild: ['damn', 'hell', 'crap'],
      moderate: ['shit', 'piss', 'bastard', 'bitch'],
      severe: ['fuck', 'asshole', 'bullshit', 'fucking', 'motherfucker']
    },
    hindi: {
      mild: ['kamina', 'saala'],
      moderate: ['kutiya', 'harami', 'gandu'],
      severe: ['madarchod', 'bhenchod', 'bhosdike', 'randi', 'chutiya', 'gaand', 'lund']
    }
  };

  // Creative punishment types
  const punishmentTypes = [
    { id: 'timeout', name: 'Time Out Corner', message: '😭 Go sit in the corner and think about what you said!', duration: 30000 },
    { id: 'typing', name: 'Type Apology', message: '✍️ Type "I will not use bad words" 5 times!', duration: 0 },
    { id: 'meditation', name: 'Mindfulness Break', message: '🧘‍♀️ Take 3 deep breaths and think happy thoughts!', duration: 20000 },
    { id: 'dance', name: 'Silly Dance', message: '💃 Do a silly dance to shake off the negativity!', duration: 15000 },
    { id: 'compliment', name: 'Say Something Nice', message: '😊 Say 3 nice things about yourself out loud!', duration: 0 }
  ];

  // Achievements list
  const achievementsList = [
    { id: 'first_day', name: 'First Day Clean', description: 'Completed your first day without violations', icon: '🌟', coins: 10 },
    { id: 'week_warrior', name: 'Week Warrior', description: '7 days clean streak', icon: '🏆', coins: 50 },
    { id: 'month_master', name: 'Month Master', description: '30 days clean streak', icon: '👑', coins: 200 },
    { id: 'test_master', name: 'Test Master', description: 'Used test mode 10 times', icon: '🧪', coins: 15 }
  ];

  // Get mascot emoji based on mood
  const getMascotEmoji = () => {
    switch(mood) {
      case 'happy': return '😊';
      case 'warning': return '😐';
      case 'angry': return '😠';
      case 'locked': return '😤';
      case 'proud': return '🥳';
      default: return '😊';
    }
  };

  // Initialize speech recognition and load data
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // Create enhanced audio alerts
      alertSound.current = {
        mild: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYgBSGG0fPTgjMGHm7A7+OZURE'),
        severe: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYgBSGG0fPTgjMGHm7A7+OZURE'),
        achievement: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2+LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYgBSGG0fPTgjMGHm7A7+OZURE')
      };

      // Initialize speech recognition
      if ('webkitSpeechRecognition' in window) {
        speechRecognition.current = new window.webkitSpeechRecognition();
      } else if ('SpeechRecognition' in window) {
        speechRecognition.current = new window.SpeechRecognition();
      }

      if (speechRecognition.current) {
        speechRecognition.current.continuous = true;
        speechRecognition.current.interimResults = true;
        speechRecognition.current.lang = 'en-US';

        speechRecognition.current.onresult = (event) => {
          let currentTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            currentTranscript += event.results[i][0].transcript;
          }
          setTranscript(currentTranscript);
          analyzeProfanity(currentTranscript);
        };

        speechRecognition.current.onerror = (event) => {
          console.error('Speech recognition error:', event.error);
          setIsListening(false);
        };

        speechRecognition.current.onend = () => {
          if (isListening) {
            setTimeout(() => {
              if (isListening && speechRecognition.current) {
                speechRecognition.current.start();
              }
            }, 100);
          }
        };
      }

      loadSettings();
      updateMood();
    }
  }, []);

  // Load settings and data
  const loadSettings = () => {
    const savedSettings = localStorage.getItem('speechGuardSettings');
    const savedHistory = localStorage.getItem('speechGuardHistory');
    const savedStreak = localStorage.getItem('speechGuardStreak');
    const savedAchievements = localStorage.getItem('speechGuardAchievements');
    const savedCoins = localStorage.getItem('speechGuardCoins');
    const savedLevel = localStorage.getItem('speechGuardLevel');
    const savedXP = localStorage.getItem('speechGuardXP');

    if (savedSettings) setSettings(JSON.parse(savedSettings));
    if (savedHistory) setDetectionHistory(JSON.parse(savedHistory));
    if (savedStreak) setStreak(parseInt(savedStreak));
    if (savedAchievements) setAchievements(JSON.parse(savedAchievements));
    if (savedCoins) setCoins(parseInt(savedCoins));
    if (savedLevel) setLevel(parseInt(savedLevel));
    if (savedXP) setXp(parseInt(savedXP));
  };

  // Save to localStorage
  const saveToStorage = (key, data) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  // Update mood based on current state
  const updateMood = () => {
    if (punishment.isActive) {
      setMood('locked');
    } else if (punishment.strikes >= 2) {
      setMood('angry');
    } else if (punishment.strikes >= 1) {
      setMood('warning');
    } else if (streak >= 7) {
      setMood('proud');
    } else {
      setMood('happy');
    }
  };

  // Add XP and handle level ups
  const addXP = (amount) => {
    const newXP = xp + amount;
    const newLevel = Math.floor(newXP / 100) + 1;
    
    if (newLevel > level) {
      triggerConfetti();
      setCoins(prev => prev + newLevel * 10);
      if (settings.alerts.sound) {
        alertSound.current.achievement.play().catch(() => {});
      }
    }
    
    setXp(newXP);
    setLevel(newLevel);
    saveToStorage('speechGuardXP', newXP);
    saveToStorage('speechGuardLevel', newLevel);
  };

  // Trigger confetti effect
  const triggerConfetti = () => {
    setShowConfetti(true);
    setTimeout(() => setShowConfetti(false), 3000);
  };

  // Toggle listening
  const toggleListening = () => {
    if (!speechRecognition.current) {
      alert('Speech recognition not supported in this browser');
      return;
    }

    if (punishment.isActive) {
      alert('Cannot listen while punishment is active! 😤');
      return;
    }

    if (isListening) {
      speechRecognition.current.stop();
      setIsListening(false);
    } else {
      speechRecognition.current.start();
      setIsListening(true);
      addXP(1); // Small XP reward for starting
    }
  };

  // Enhanced profanity analysis with severity
  const analyzeProfanity = (text) => {
    const normalizedText = text.toLowerCase();
    
    for (const [category, enabled] of Object.entries(settings.categories)) {
      if (!enabled) continue;
      
      const categoryWords = profanityDict[category] || {};
      
      for (const [severity, words] of Object.entries(categoryWords)) {
        const allWords = [...words, ...customWords];
        
        for (const word of allWords) {
          if (normalizedText.includes(word)) {
            handleDetection(word, category, severity);
            return;
          }
        }
      }
    }
  };

  // Handle profanity detection with creative punishments
  const handleDetection = (word, category, severity = 'moderate') => {
    const detection = {
      word,
      category,
      severity,
      time: new Date().toLocaleTimeString(),
      timestamp: Date.now()
    };
    
    // Add to history
    const newHistory = [detection, ...detectionHistory].slice(0, 50);
    setDetectionHistory(newHistory);
    saveToStorage('speechGuardHistory', newHistory);
    
    // Show alert
    showAlert(detection);
    
    // Apply creative punishment
    applyCreativePunishment(severity);
    
    // Reset streak and trigger effects
    resetStreak();
    triggerScreenShake();
    
    // Pause listening
    if (isListening) {
      speechRecognition.current.stop();
      setTimeout(() => {
        if (!punishment.isActive && isListening) {
          speechRecognition.current.start();
        }
      }, 2000);
    }
    
    updateMood();
  };

  // Apply creative punishment system
  const applyCreativePunishment = (severity) => {
    const newStrikes = punishment.strikes + 1;
    let punishmentType;
    
    const strikeLimit = settings.hardcore ? 2 : 3;
    
    if (newStrikes >= strikeLimit) {
      // Pick random punishment
      punishmentType = punishmentTypes[Math.floor(Math.random() * punishmentTypes.length)];
      setCurrentPunishment(punishmentType);
      
      setPunishment({ 
        strikes: newStrikes, 
        isActive: true,
        type: punishmentType.id,
        timeLeft: punishmentType.duration
      });
      
      if (punishmentType.duration > 0) {
        setTimeout(() => {
          setPunishment(prev => ({ ...prev, isActive: false }));
          setCurrentPunishment(null);
          addXP(20); // Reward for completing punishment
        }, punishmentType.duration);
      }
    } else {
      setPunishment({ strikes: newStrikes, isActive: false, type: 'warning', timeLeft: 0 });
    }
    
    updateMood();
  };

  // Show enhanced alert
  const showAlert = (detection) => {
    setAlert({
      show: true,
      text: `🚨 NAUGHTY WORD DETECTED: ${detection.word.toUpperCase()}!`,
      word: detection.word,
      category: detection.category,
      time: detection.time
    });

    // Play sound based on severity
    if (settings.alerts.sound && alertSound.current) {
      if (detection.severity === 'severe') {
        alertSound.current.severe.play().catch(() => {});
      } else {
        alertSound.current.mild.play().catch(() => {});
      }
    }

    // Enhanced vibration patterns
    if (settings.alerts.vibration && navigator.vibrate) {
      if (detection.severity === 'severe') {
        navigator.vibrate([300, 100, 300, 100, 300]);
      } else {
        navigator.vibrate([200, 100, 200]);
      }
    }

    setTimeout(() => {
      setAlert(prev => ({ ...prev, show: false }));
    }, 4000);
  };

  // Reset streak with penalty
  const resetStreak = () => {
    if (streak > 0) {
      setCoins(prev => Math.max(0, prev - 5)); // Lose 5 coins
    }
    setStreak(0);
    saveToStorage('speechGuardStreak', 0);
  };

  // Screen shake effect
  const triggerScreenShake = () => {
    setShakeScreen(true);
    setTimeout(() => setShakeScreen(false), 600);
  };

  // Complete punishment task
  const completePunishmentTask = () => {
    if (currentPunishment && currentPunishment.duration === 0) {
      setPunishment(prev => ({ ...prev, isActive: false }));
      setCurrentPunishment(null);
      addXP(25);
      setCoins(prev => prev + 10);
    }
  };

  // Test detection
  const testDetection = (text) => {
    if (text.trim()) {
      analyzeProfanity(text);
    }
  };

  // Toggle theme
  const toggleTheme = () => {
    const newTheme = settings.theme === 'light' ? 'dark' : 'light';
    const newSettings = { ...settings, theme: newTheme };
    setSettings(newSettings);
    saveToStorage('speechGuardSettings', newSettings);
  };

  return (
    <div className={`min-h-screen transition-all duration-300 ${
      shakeScreen ? 'animate-shake' : ''
    } ${settings.theme === 'dark' 
      ? 'bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white' 
      : 'bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 text-gray-900'
    }`}>
      
      {/* Confetti Effect */}
      {showConfetti && (
        <div className="fixed inset-0 pointer-events-none z-50">
          <div className="confetti">🎉</div>
          <div className="confetti">🎊</div>
          <div className="confetti">⭐</div>
          <div className="confetti">🌟</div>
          <div className="confetti">✨</div>
          <div className="confetti">🎈</div>
        </div>
      )}

      <div className="max-w-5xl mx-auto p-6">
        {/* Enhanced Header with Stats */}
        <div className="flex justify-between items-center mb-8 pb-6 border-b-2 border-gradient-to-r from-pink-300 to-purple-300">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-20 h-20 bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 rounded-full flex items-center justify-center text-4xl animate-bounce shadow-2xl">
                {getMascotEmoji()}
              </div>
              <div className="absolute -top-2 -right-2 w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center text-sm font-bold border-2 border-white">
                {level}
              </div>
            </div>
            <div>
              <h1 className="text-5xl font-black bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 bg-clip-text text-transparent drop-shadow-lg">
                Speech Guard 2.0
              </h1>
              <div className="text-lg font-semibold text-gray-700 dark:text-gray-300">
                Level {level} Guardian • {coins} 🪙 • XP: {xp}/100
              </div>
              <div className="w-40 h-3 bg-gray-200 rounded-full mt-2 shadow-inner">
                <div 
                  className="h-3 bg-gradient-to-r from-green-400 to-blue-500 rounded-full transition-all duration-500 shadow-sm"
                  style={{ width: `${(xp % 100)}%` }}
                />
              </div>
            </div>
          </div>
          <button
            onClick={() => setShowSettings(true)}
            className="w-16 h-16 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full shadow-2xl flex items-center justify-center hover:shadow-3xl transition-all duration-300 hover:scale-110 text-3xl"
            aria-label="Open Settings"
          >
            ⚙️
          </button>
        </div>

        {/* Main Control Button */}
        <div className="text-center mb-10">
          <button
            onClick={toggleListening}
            className={`w-48 h-48 rounded-full text-3xl font-black transition-all duration-500 mb-6 relative overflow-hidden shadow-2xl ${
              isListening 
                ? 'bg-gradient-to-r from-red-400 via-red-500 to-red-600 text-white animate-pulse scale-110 shadow-red-500/50' 
                : punishment.isActive
                ? 'bg-gray-400 text-gray-600 cursor-not-allowed'
                : 'bg-gradient-to-r from-green-400 via-green-500 to-green-600 text-white hover:scale-105 hover:shadow-green-500/50'
            }`}
            disabled={punishment.isActive}
          >
            <div className="absolute inset-0 bg-white opacity-20 rounded-full animate-ping" />
            <div className="relative z-10">
              {punishment.isActive ? (
                <div>
                  <div className="text-4xl mb-2">🔒</div>
                  <div className="text-lg">LOCKED</div>
                </div>
              ) : isListening ? (
                <div>
                  <div className="text-4xl mb-2">🛑</div>
                  <div className="text-lg">STOP</div>
                </div>
              ) : (
                <div>
                  <div className="text-4xl mb-2">🎤</div>
                  <div className="text-lg">START</div>
                </div>
              )}
            </div>
          </button>
          <div className="text-2xl font-bold">
            {punishment.isActive ? '🚫 Punishment Mode Active!' : 
             isListening ? '👂 Listening for naughty words...' : 
             '😊 Ready to be your language guardian!'}
          </div>
        </div>

        {/* Enhanced Streak Display */}
        <div className="bg-gradient-to-br from-yellow-200 via-orange-200 to-red-200 dark:from-yellow-800 dark:via-orange-700 dark:to-red-600 rounded-3xl p-10 shadow-2xl mb-10 text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="text-9xl absolute top-6 left-6 animate-pulse">🔥</div>
            <div className="text-8xl absolute top-8 right-8 animate-bounce">⭐</div>
            <div className="text-7xl absolute bottom-6 left-1/2 transform -translate-x-1/2 animate-pulse">✨</div>
          </div>
          <div className="relative z-10">
            <div className="text-3xl font-black text-orange-800 dark:text-orange-200 mb-4 animate-pulse">
              🔥 EPIC CLEAN STREAK 🔥
            </div>
            <div className="text-9xl font-black text-orange-600 dark:text-orange-300 mb-4 animate-bounce drop-shadow-lg">
              {streak}
            </div>
            <div className="text-3xl font-black text-orange-800 dark:text-orange-200">
              {streak === 1 ? 'day' : 'days'} of pure speech!
            </div>
            {streak >= 7 && (
              <div className="mt-6 text-2xl font-bold text-orange-700 dark:text-orange-200 animate-pulse">
                🏆 LEGENDARY STATUS! You're unstoppable! 🏆
              </div>
            )}
          </div>
        </div>

        {/* Creative Punishment Display */}
        {punishment.isActive && currentPunishment && (
          <div className="bg-gradient-to-br from-red-500 via-pink-500 to-purple-600 text-white rounded-3xl p-10 shadow-2xl mb-10 text-center animate-pulse">
            <div className="text-4xl mb-6 animate-bounce">🚨 PUNISHMENT TIME! 🚨</div>
            <div className="text-8xl mb-6 animate-spin-slow">😤</div>
            <div className="text-3xl font-bold mb-6">{currentPunishment.name}</div>
            <div className="text-2xl mb-8 bg-white bg-opacity-20 rounded-2xl p-4">{currentPunishment.message}</div>
            
            {currentPunishment.duration === 0 && (
              <button
                onClick={completePunishmentTask}
                className="bg-white text-purple-600 px-12 py-6 rounded-full font-bold text-2xl hover:bg-gray-100 transition-all transform hover:scale-110 shadow-lg"
              >
                ✅ I've Completed My Task!
              </button>
            )}
            
            {currentPunishment.duration > 0 && (
              <div className="text-2xl font-bold bg-white bg-opacity-20 rounded-2xl p-4">
                ⏰ Time remaining: {Math.ceil(punishment.timeLeft / 1000)} seconds
              </div>
            )}
          </div>
        )}

        {/* Strike Warning System */}
        {punishment.strikes > 0 && !punishment.isActive && (
          <div className={`rounded-3xl p-8 shadow-2xl mb-10 text-center transform hover:scale-105 transition-all ${
            punishment.strikes === 1 ? 'bg-gradient-to-r from-yellow-400 to-orange-500 animate-pulse' :
            punishment.strikes === 2 ? 'bg-gradient-to-r from-orange-500 to-red-600 animate-bounce' :
            'bg-gradient-to-r from-red-600 to-purple-700 animate-shake'
          }`}>
            <div className="text-6xl mb-4">
              {punishment.strikes === 1 ? '⚠️' : punishment.strikes === 2 ? '🔥' : '💀'}
            </div>
            <div className="text-4xl font-black text-white mb-4">
              Strike {punishment.strikes}/{settings.hardcore ? '2' : '3'}
            </div>
            <div className="text-2xl font-bold text-white">
              {punishment.strikes === 1 ? 'First warning! Watch your language! 😅' :
               punishment.strikes === 2 ? 'FINAL WARNING! One more strike = punishment! 😰' :
               'CRITICAL! Next violation triggers punishment! 😱'}
            </div>
          </div>
        )}

        {/* Enhanced Test Mode */}
        {settings.testMode && (
          <div className="bg-gradient-to-br from-blue-100 to-purple-200 dark:from-blue-900 dark:to-purple-800 rounded-3xl p-8 shadow-2xl mb-10">
            <h3 className="text-3xl font-bold mb-6 text-center">🧪 TESTING LABORATORY 🧪</h3>
            <div className="flex gap-4">
              <input
                type="text"
                placeholder="Type something naughty to test the detector... 😈"
                className="flex-1 px-8 py-6 rounded-2xl border-3 border-purple-400 bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-xl font-semibold focus:border-purple-600 focus:ring-4 focus:ring-purple-200 shadow-lg"
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    testDetection(e.target.value);
                    e.target.value = '';
                  }
                }}
              />
              <button
                onClick={(e) => {
                  const input = e.target.previousElementSibling;
                  testDetection(input.value);
                  input.value = '';
                }}
                className="px-10 py-6 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl hover:from-purple-600 hover:to-pink-600 transition-all transform hover:scale-105 font-bold text-xl shadow-lg"
              >
                🚀 TEST NOW!
              </button>
            </div>
          </div>
        )}

        {/* Enhanced Transcript */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-10 shadow-2xl mb-10 relative overflow-hidden">
          <div className="absolute top-4 right-4 text-8xl opacity-10">🎙️</div>
          <h3 className="text-3xl font-bold mb-8 text-center">📝 LIVE TRANSCRIPT</h3>
          <div className="min-h-[150px] p-8 bg-gradient-to-r from-gray-50 to-blue-50 dark:from-gray-700 dark:to-blue-800 rounded-2xl text-gray-700 dark:text-gray-300 text-xl relative shadow-inner">
            {isListening && (
              <div className="absolute top-4 right-4 flex space-x-2">
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse delay-75"></div>
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse delay-150"></div>
                <span className="text-red-500 font-bold ml-2">LIVE</span>
              </div>
            )}
            <div className="font-mono">{transcript}</div>
          </div>
        </div>

        {/* Enhanced History */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-10 shadow-2xl mb-10">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-3xl font-bold">📚 HALL OF SHAME</h3>
            <button
              onClick={() => {
                setDetectionHistory([]);
                saveToStorage('speechGuardHistory', []);
              }}
              className="px-8 py-4 bg-gradient-to-r from-red-500 to-red-700 text-white rounded-2xl hover:from-red-600 hover:to-red-800 transition-all transform hover:scale-105 font-bold text-lg shadow-lg"
            >
              🗑️ Clear Shame
            </button>
          </div>
          <div className="space-y-6 max-h-96 overflow-y-auto">
            {detectionHistory.length === 0 ? (
              <div className="text-center text-gray-500 py-16 text-2xl">
                🎉 PERFECT RECORD! No naughty words detected! 🎉
              </div>
            ) : (
              detectionHistory.slice(0, 15).map((item, index) => (
                <div key={index} className="flex justify-between items-center p-6 bg-gradient-to-r from-red-50 to-pink-100 dark:from-red-900 dark:to-pink-800 rounded-2xl border-l-8 border-red-500 transform hover:scale-102 transition-all shadow-lg">
                  <div className="flex items-center gap-6">
                    <div className="text-4xl">
                      {item.severity === 'severe' ? '🚨' : item.severity === 'moderate' ? '⚠️' : '😬'}
                    </div>
                    <div>
                      <div className="font-bold text-red-600 dark:text-red-400 text-2xl">
                        {item.word}
                      </div>
                      <div className="text-lg text-gray-600 dark:text-gray-400 capitalize">
                        {item.category} • {item.severity} severity
                      </div>
                    </div>
                  </div>
                  <div className="text-lg text-gray-500 font-mono bg-gray-100 dark:bg-gray-700 px-4 py-2 rounded-lg">
                    {item.time}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Achievements Section */}
        <div className="bg-gradient-to-br from-yellow-100 to-gold-200 dark:from-yellow-900 dark:to-gold-800 rounded-3xl p-10 shadow-2xl mb-10">
          <h3 className="text-3xl font-bold mb-8 text-center">🏆 LEGENDARY ACHIEVEMENTS 🏆</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {achievementsList.map((achievement) => (
              <div
                key={achievement.id}
                className={`p-6 rounded-2xl text-center transition-all transform hover:scale-110 shadow-lg ${
                  achievements.includes(achievement.id)
                    ? 'bg-gradient-to-r from-green-400 to-blue-500 text-white shadow-xl animate-pulse'
                    : 'bg-gray-200 dark:bg-gray-700 text-gray-500'
                }`}
              >
                <div className="text-5xl mb-4">{achievement.icon}</div>
                <div className="font-bold text-lg mb-2">{achievement.name}</div>
                <div className="text-sm mb-2">{achievement.description}</div>
                <div className="text-lg font-bold">{achievement.coins} 🪙</div>
              </div>
            ))}
          </div>
        </div>

        {/* Privacy Notice */}
        <div className="text-center text-gray-500 dark:text-gray-400 text-lg bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg">
          🔒 <span className="font-bold">PRIVACY GUARANTEED!</span> Everything happens locally - no snitching to servers! 🤐
          <br />
          <span className="font-black text-xl bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
            Speech Guard v2.0
          </span> - Now with 500% more fun! 🎉
        </div>
      </div>

      {/* Enhanced Alert */}
      {alert.show && (
        <div className="fixed top-8 right-8 p-10 rounded-3xl shadow-2xl z-50 max-w-md transform transition-all duration-500 animate-bounce bg-gradient-to-r from-red-400 via-pink-500 to-red-600 text-white border-4 border-white">
          <div className="text-center">
            <div className="text-6xl mb-4 animate-spin">🚨</div>
            <div className="font-black text-2xl mb-4">LANGUAGE VIOLATION!</div>
            <div className="mb-4 text-xl font-bold bg-white bg-opacity-20 rounded-lg p-3">{alert.text}</div>
            <div className="text-lg opacity-90 font-mono">{alert.time}</div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-10 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="flex justify-between items-center mb-10">
              <h2 className="text-4xl font-black bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
                ⚙️ CONTROL PANEL ⚙️
              </h2>
              <button
                onClick={() => setShowSettings(false)}
                className="w-12 h-12 flex items-center justify-center text-gray-500 hover:text-gray-700 text-4xl hover:bg-gray-100 rounded-full transition-all"
              >
                ✖️
              </button>
            </div>

            {/* Theme Toggle */}
            <div className="mb-10 p-8 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900 dark:to-purple-900 rounded-2xl">
              <label className="block text-2xl font-bold mb-6">🎨 Theme Selection</label>
              <div className="flex items-center gap-6 text-xl">
                <span>☀️ Light Mode</span>
                <button
                  onClick={toggleTheme}
                  className={`w-20 h-10 rounded-full transition-all duration-300 relative ${
                    settings.theme === 'dark' ? 'bg-purple-500' : 'bg-gray-300'
                  }`}
                >
                  <div className={`w-8 h-8 bg-white rounded-full absolute top-1 transition-transform duration-300 ${
                    settings.theme === 'dark' ? 'translate-x-11' : 'translate-x-1'
                  }`} />
                </button>
                <span>🌙 Dark Mode</span>
              </div>
            </div>

            {/* Fun Mode Toggle */}
            <div className="mb-10 p-8 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900 dark:to-blue-900 rounded-2xl">
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-2xl font-bold">🎮 Fun Mode</span>
                  <div className="text-lg text-gray-600 dark:text-gray-400">Extra animations, effects, and playful interactions</div>
                </div>
                <button
                  onClick={() => {
                    const newSettings = { ...settings, funMode: !settings.funMode };
                    setSettings(newSettings);
                    saveToStorage('speechGuardSettings', newSettings);
                  }}
                  className={`w-20 h-10 rounded-full transition-all duration-300 relative ${
                    settings.funMode ? 'bg-green-500' : 'bg-gray-300'
                  }`}
                >
                  <div className={`w-8 h-8 bg-white rounded-full absolute top-1 transition-transform duration-300 ${
                    settings.funMode ? 'translate-x-11' : 'translate-x-1'
                  }`} />
                </button>
              </div>
            </div>

            {/* Hardcore Mode Toggle */}
            <div className="mb-10 p-8 bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-900 dark:to-orange-900 rounded-2xl">
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-2xl font-bold">💀 Hardcore Mode</span>
                  <div className="text-lg text-gray-600 dark:text-gray-400">Stricter punishments (2 strikes instead of 3)</div>
                </div>
                <button
                  onClick={() => {
                    const newSettings = { ...settings, hardcore: !settings.hardcore };
                    setSettings(newSettings);
                    saveToStorage('speechGuardSettings', newSettings);
                  }}
                  className={`w-20 h-10 rounded-full transition-all duration-300 relative ${
                    settings.hardcore ? 'bg-red-500' : 'bg-gray-300'
                  }`}
                >
                  <div className={`w-8 h-8 bg-white rounded-full absolute top-1 transition-transform duration-300 ${
                    settings.hardcore ? 'translate-x-11' : 'translate-x-1'
                  }`} />
                </button>
              </div>
            </div>

            {/* Detection Categories */}
            <div className="mb-10 p-8 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900 dark:to-pink-900 rounded-2xl">
              <label className="block text-2xl font-bold mb-6">🎯 Detection Categories</label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.entries(settings.categories).map(([category, enabled]) => (
                  <div key={category} className="flex justify-between items-center p-4 bg-white dark:bg-gray-700 rounded-xl shadow-lg">
                    <span className="capitalize text-xl font-semibold">
                      {category === 'sexual' ? '🔞' : category === 'abusive' ? '😡' : category === 'hate' ? '💢' : category === 'profanity' ? '🤬' : '🇮🇳'} {category}
                    </span>
                    <button
                      onClick={() => {
                        const newSettings = {
                          ...settings,
                          categories: { ...settings.categories, [category]: !enabled }
                        };
                        setSettings(newSettings);
                        saveToStorage('speechGuardSettings', newSettings);
                      }}
                      className={`w-16 h-8 rounded-full transition-all duration-300 relative ${
                        enabled ? 'bg-green-500' : 'bg-gray-300'
                      }`}
                    >
                      <div className={`w-6 h-6 bg-white rounded-full absolute top-1 transition-transform duration-300 ${
                        enabled ? 'translate-x-9' : 'translate-x-1'
                      }`} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Test Mode Toggle */}
            <div className="mb-10 p-8 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900 dark:to-orange-900 rounded-2xl">
              <div className="flex justify-between items-center">
                <span className="text-2xl font-bold">🧪 Test Mode</span>
                <button
                  onClick={() => {
                    const newSettings = { ...settings, testMode: !settings.testMode };
                    setSettings(newSettings);
                    saveToStorage('speechGuardSettings', newSettings);
                  }}
                  className={`w-20 h-10 rounded-full transition-all duration-300 relative ${
                    settings.testMode ? 'bg-yellow-500' : 'bg-gray-300'
                  }`}
                >
                  <div className={`w-8 h-8 bg-white rounded-full absolute top-1 transition-transform duration-300 ${
                    settings.testMode ? 'translate-x-11' : 'translate-x-1'
                  }`} />
                </button>
              </div>
            </div>

            {/* Data Management */}
            <div className="space-y-6">
              <button
                onClick={() => {
                  const data = { settings, history: detectionHistory, streak, customWords, achievements, coins, level, xp };
                  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'speech-guard-data.json';
                  a.click();
                  URL.revokeObjectURL(url);
                }}
                className="w-full py-6 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-2xl hover:from-blue-600 hover:to-purple-700 transition-all font-bold text-2xl transform hover:scale-105 shadow-lg"
              >
                📥 Export My Epic Data
              </button>
              <button
                onClick={() => {
                  if (confirm('🗑️ Delete EVERYTHING? This action cannot be undone!')) {
                    localStorage.clear();
                    location.reload();
                  }
                }}
                className="w-full py-6 bg-gradient-to-r from-red-500 to-red-700 text-white rounded-2xl hover:from-red-600 hover:to-red-800 transition-all font-bold text-2xl transform hover:scale-105 shadow-lg"
              >
                🗑️ Nuclear Reset (Clear All)
              </button>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        @keyframes slide-in-right {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 30%, 50%, 70%, 90% { transform: translateX(-15px); }
          20%, 40%, 60%, 80% { transform: translateX(15px); }
        }
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-slide-in-right { animation: slide-in-right 0.4s ease-out; }
        .animate-shake { animation: shake 0.6s ease-in-out; }
        .animate-spin-slow { animation: spin-slow 4s linear infinite; }
        .confetti {
          position: absolute;
          font-size: 3rem;
          animation: confetti-fall 4s linear infinite;
        }
        .confetti:nth-child(1) { left: 5%; animation-delay: 0s; }
        .confetti:nth-child(2) { left: 25%; animation-delay: 0.8s; }
        .confetti:nth-child(3) { left: 45%; animation-delay: 1.6s; }
        .confetti:nth-child(4) { left: 65%; animation-delay: 2.4s; }
        .confetti:nth-child(5) { left: 85%; animation-delay: 3.2s; }
        .confetti:nth-child(6) { left: 50%; animation-delay: 1.2s; }
        @keyframes confetti-fall {
          0% { transform: translateY(-100vh) rotate(0deg); opacity: 1; }
          100% { transform: translateY(100vh) rotate(1080deg); opacity: 0; }
        }
      `}</style>
    </div>
  );
}