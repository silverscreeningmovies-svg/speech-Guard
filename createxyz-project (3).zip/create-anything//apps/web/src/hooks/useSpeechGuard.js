import { useState, useEffect, useRef, useCallback } from "react";
import { profanityDict, punishmentTypes, achievementsList } from "@/app/speech-guard/lib/constants";

export function useSpeechGuard() {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("Speech will appear here...");
  const [detectionHistory, setDetectionHistory] = useState([]);
  const [streak, setStreak] = useState(0);
  const [punishment, setPunishment] = useState({
    strikes: 0,
    isActive: false,
    type: "none",
    duration: 0,
    message: "",
  });
  const [showSettings, setShowSettings] = useState(false);
  const [settings, setSettings] = useState({
    theme: "light",
    sensitivity: "medium",
    categories: { sexual: true, abusive: true, hate: true, profanity: true, hindi: true },
    alerts: { sound: true, vibration: true },
    testMode: false,
    debug: false,
    funMode: true,
    hardcore: false,
  });
  const [customWords, setCustomWords] = useState([]);
  const [alert, setAlert] = useState({ show: false, text: "", word: "", category: "", time: "" });
  const [achievements, setAchievements] = useState([]);
  const [coins, setCoins] = useState(0);
  const [level, setLevel] = useState(1);
  const [xp, setXp] = useState(0);
  const [shakeScreen, setShakeScreen] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [mood, setMood] = useState("happy");
  const [currentPunishment, setCurrentPunishment] = useState(null);

  const speechRecognition = useRef(null);
  const alertSound = useRef(null);

  const saveToStorage = (key, data) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  const showAlert = useCallback((detection) => {
    const isAchievement = detection.category === "achievement";
    setAlert({
      show: true,
      text: isAchievement ? detection.text : `🚨 ${detection.word.toUpperCase()} detected!`,
      word: detection.word,
      category: detection.category,
      time: detection.time,
    });

    if (settings.alerts.sound && alertSound.current) {
      if (isAchievement) alertSound.current.achievement.play().catch(() => {});
      else if (detection.severity === "severe") alertSound.current.severe.play().catch(() => {});
      else alertSound.current.mild.play().catch(() => {});
    }

    if (settings.alerts.vibration && navigator.vibrate) {
      if (isAchievement) navigator.vibrate([100, 50, 100, 50, 100]);
      else if (detection.severity === "severe") navigator.vibrate([300, 100, 300, 100, 300]);
      else navigator.vibrate([200, 100, 200]);
    }

    setTimeout(() => setAlert((prev) => ({ ...prev, show: false })), isAchievement ? 5000 : 3000);
  }, [settings.alerts.sound, settings.alerts.vibration]);
  
  const addXP = useCallback((amount) => {
    setXp((prevXp) => {
        const newXP = prevXp + amount;
        const newLevel = Math.floor(newXP / 100) + 1;

        if (newLevel > level) {
            setShowConfetti(true);
            setTimeout(() => setShowConfetti(false), 3000);
            if (settings.alerts.sound) alertSound.current?.achievement.play().catch(() => {});
            setCoins((prevCoins) => {
                const updatedCoins = prevCoins + newLevel * 10;
                saveToStorage("speechGuardCoins", updatedCoins);
                return updatedCoins;
            });
        }

        setLevel(newLevel);
        saveToStorage("speechGuardXP", newXP);
        saveToStorage("speechGuardLevel", newLevel);
        return newXP;
    });
  }, [level, settings.alerts.sound]);

  const showAchievementNotification = useCallback((achievement) => {
    showAlert({
      text: `🎉 Achievement Unlocked: ${achievement.name}!`,
      word: achievement.description,
      category: "achievement",
      time: new Date().toLocaleTimeString(),
    });
  }, [showAlert]);
  
  const checkAchievements = useCallback((type, value) => {
    const newAchievements = [];
    achievementsList.forEach((achievement) => {
      if (!achievements.includes(achievement.id)) {
        let unlock = false;
        switch (achievement.id) {
          case "first_day": unlock = streak >= 1; break;
          case "week_warrior": unlock = streak >= 7; break;
          case "month_master": unlock = streak >= 30; break;
          case "reformed": unlock = type === "reform" && value >= 1; break;
          case "test_master": unlock = type === "test" && value >= 10; break;
        }
        if (unlock) {
          newAchievements.push(achievement.id);
          setCoins((prev) => prev + achievement.coins);
          addXP(50);
          showAchievementNotification(achievement);
        }
      }
    });
    if (newAchievements.length > 0) {
      const updatedAchievements = [...achievements, ...newAchievements];
      setAchievements(updatedAchievements);
      saveToStorage("speechGuardAchievements", updatedAchievements);
    }
  }, [achievements, addXP, showAchievementNotification, streak]);
  
  const updateMood = useCallback(() => {
    setMood((prevMood) => {
        if (punishment.isActive) return "locked";
        if (punishment.strikes >= 2) return "angry";
        if (punishment.strikes >= 1) return "warning";
        if (streak >= 7) return "proud";
        return "happy";
    });
  }, [punishment.isActive, punishment.strikes, streak]);

  const resetStreak = useCallback(() => {
    if (streak > 0) {
      setCoins((prev) => {
          const newCoins = Math.max(0, prev - 5);
          saveToStorage("speechGuardCoins", newCoins);
          return newCoins;
      });
    }
    setStreak(0);
    saveToStorage("speechGuardStreak", 0);
  }, [streak]);

  const triggerScreenShake = () => {
    setShakeScreen(true);
    setTimeout(() => setShakeScreen(false), 500);
  };
  
  const applyCreativePunishment = useCallback((severity) => {
    const newStrikes = punishment.strikes + 1;
    let punishmentType;

    if (settings.hardcore ? newStrikes >= 2 : newStrikes >= 3) {
      punishmentType = punishmentTypes[Math.floor(Math.random() * punishmentTypes.length)];
    }

    if (punishmentType) {
      setCurrentPunishment(punishmentType);
      const newPunishment = {
        strikes: newStrikes,
        isActive: true,
        type: punishmentType.id,
        duration: punishmentType.duration,
        message: punishmentType.message,
      };
      setPunishment(newPunishment);

      if (punishmentType.duration > 0) {
        setTimeout(() => {
          setPunishment((prev) => ({ ...prev, isActive: false }));
          setCurrentPunishment(null);
          addXP(10);
        }, punishmentType.duration);
      }
    } else {
      setPunishment({ strikes: newStrikes, isActive: false, type: "warning", duration: 0, message: "" });
    }
  }, [punishment.strikes, settings.hardcore, addXP]);

  const handleDetection = useCallback((word, category, severity = "moderate") => {
    const detection = { word, category, severity, time: new Date().toLocaleTimeString(), timestamp: Date.now() };
    const newHistory = [detection, ...detectionHistory].slice(0, 50);
    setDetectionHistory(newHistory);
    saveToStorage("speechGuardHistory", newHistory);
    showAlert(detection);
    applyCreativePunishment(severity);
    resetStreak();
    triggerScreenShake();
    if (isListening) {
      speechRecognition.current?.stop();
      setTimeout(() => {
        if (!punishment.isActive && isListening) {
          speechRecognition.current?.start();
        }
      }, 2000);
    }
  }, [detectionHistory, showAlert, applyCreativePunishment, resetStreak, isListening, punishment.isActive]);

  const analyzeProfanity = useCallback((text) => {
    const normalizedText = text.toLowerCase();
    for (const [category, enabled] of Object.entries(settings.categories)) {
      if (!enabled) continue;
      const categoryWords = profanityDict[category] || {};
      for (const [severity, words] of Object.entries(categoryWords)) {
        const allWords = [...words, ...customWords];
        for (const word of allWords) {
          if (normalizedText.includes(word)) {
            handleDetection(word, category, severity);
            return;
          }
        }
      }
    }
  }, [settings.categories, customWords, handleDetection]);

  useEffect(() => {
    if (typeof window !== "undefined") {
      alertSound.current = {
        mild: new Audio("data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYgBSGG0fPTgjMGHm7A7+OZURE"),
        severe: new Audio("data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2+LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYgBSGG0fPTgjMGHm7A7+OZURE"),
        achievement: new Audio("data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2+LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYgBSGG0fPTgjMGHm7A7+OZURE"),
      };
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        speechRecognition.current = new SpeechRecognition();
        speechRecognition.current.continuous = true;
        speechRecognition.current.interimResults = true;
        speechRecognition.current.lang = "en-US";
        speechRecognition.current.onresult = (event) => {
          let currentTranscript = "";
          for (let i = event.resultIndex; i < event.results.length; i++) {
            currentTranscript += event.results[i][0].transcript;
          }
          setTranscript(currentTranscript);
          analyzeProfanity(currentTranscript);
        };
        speechRecognition.current.onerror = (event) => {
          console.error("Speech recognition error:", event.error);
          setIsListening(false);
        };
        speechRecognition.current.onend = () => {
            if (speechRecognition.current && isListeningRef.current) {
                setTimeout(() => speechRecognition.current.start(), 100);
            }
        };
      }
    }
  }, [analyzeProfanity]);
  
  const isListeningRef = useRef(isListening);
    useEffect(() => {
        isListeningRef.current = isListening;
    }, [isListening]);

  useEffect(() => {
    const loadSettings = () => {
        const savedSettings = localStorage.getItem("speechGuardSettings");
        if (savedSettings) setSettings(JSON.parse(savedSettings));
        const savedHistory = localStorage.getItem("speechGuardHistory");
        if (savedHistory) setDetectionHistory(JSON.parse(savedHistory));
        const savedStreak = localStorage.getItem("speechGuardStreak");
        if (savedStreak) setStreak(parseInt(savedStreak, 10));
        const savedCustomWords = localStorage.getItem("speechGuardCustomWords");
        if (savedCustomWords) setCustomWords(JSON.parse(savedCustomWords));
        const savedAchievements = localStorage.getItem("speechGuardAchievements");
        if (savedAchievements) setAchievements(JSON.parse(savedAchievements));
        const savedCoins = localStorage.getItem("speechGuardCoins");
        if (savedCoins) setCoins(parseInt(savedCoins, 10));
        const savedLevel = localStorage.getItem("speechGuardLevel");
        if (savedLevel) setLevel(parseInt(savedLevel, 10));
        const savedXP = localStorage.getItem("speechGuardXP");
        if (savedXP) setXp(parseInt(savedXP, 10));
    };
    loadSettings();
  }, []);
  
  useEffect(() => {
      updateMood();
  }, [punishment.strikes, punishment.isActive, streak, updateMood]);
  
  const updateStreak = useCallback(() => {
    const today = new Date().toDateString();
    const lastUpdate = localStorage.getItem("speechGuardLastUpdate");
    if (lastUpdate !== today) {
      const newStreak = streak + 1;
      setStreak(newStreak);
      setCoins((prev) => prev + newStreak);
      addXP(newStreak * 10);
      saveToStorage("speechGuardStreak", newStreak);
      saveToStorage("speechGuardCoins", coins + newStreak);
      saveToStorage("speechGuardLastUpdate", today);
      checkAchievements("streak", newStreak);
    }
  }, [addXP, checkAchievements, coins, streak]);

  useEffect(() => {
    const interval = setInterval(updateStreak, 60000);
    return () => clearInterval(interval);
  }, [updateStreak]);
  
  const toggleListening = () => {
    if (!speechRecognition.current) {
      window.alert("Speech recognition not supported in this browser");
      return;
    }
    if (punishment.isActive) {
      window.alert("Cannot listen while punishment is active!");
      return;
    }
    if (isListening) {
      speechRecognition.current.stop();
      setIsListening(false);
    } else {
      speechRecognition.current.start();
      setIsListening(true);
      addXP(1);
    }
  };
  
  const testDetection = (text) => {
    if (text.trim()) {
      analyzeProfanity(text);
      const testCount = parseInt(localStorage.getItem("speechGuardTestCount") || "0", 10) + 1;
      localStorage.setItem("speechGuardTestCount", testCount.toString());
      checkAchievements("test", testCount);
    }
  };

  const completePunishmentTask = () => {
    if (currentPunishment && currentPunishment.duration === 0) {
      setPunishment((prev) => ({ ...prev, isActive: false }));
      setCurrentPunishment(null);
      addXP(20);
      setCoins((prev) => prev + 5);
    }
  };

  const handleSettingsChange = (newSettings) => {
    setSettings(newSettings);
    saveToStorage("speechGuardSettings", newSettings);
  };
  
  const clearHistory = () => {
    setDetectionHistory([]);
    saveToStorage("speechGuardHistory", []);
  };

  return {
    state: { isListening, transcript, detectionHistory, streak, punishment, showSettings, settings, alert, achievements, coins, level, xp, shakeScreen, showConfetti, mood, currentPunishment, customWords },
    actions: { setIsListening, setTranscript, setDetectionHistory, setStreak, setPunishment, setShowSettings, setSettings: handleSettingsChange, setAlert, setAchievements, setCoins, setLevel, setXp, setShakeScreen, setShowConfetti, setMood, setCurrentPunishment, toggleListening, testDetection, completePunishmentTask, addXP, clearHistory, saveToStorage }
  };
}